import React from 'react';
import { EvidenceChart } from './EvidenceChart';
import { TimelineChart } from './TimelineChart';
import { ActionLog } from './ActionLog';
import { SuccessStory } from './SuccessStory';

interface LegalStrategyProps {
  onNavigate?: (page: string) => void;
}

export const LegalStrategy: React.FC<LegalStrategyProps> = ({ onNavigate }) => {
  
  const handleHashingClick = () => {
    onNavigate?.('guide');
    // Optional: Add a small delay to allow page render then scroll, or rely on user scrolling down
    setTimeout(() => {
        const element = document.getElementById('hashing-explained');
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
  };

  return (
    <section id="legal-strategy" className="mb-16 raised-card rounded-2xl overflow-hidden">
      
      {/* Header */}
      <div className="p-8 border-b border-neutral-700 bg-neutral-900/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <span className="text-cyan-400 font-black text-[10px] uppercase tracking-widest block mb-1">Command & Control</span>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Strategy Dashboard</h3>
            </div>
            <p className="text-xs text-gray-400 font-medium max-w-xs leading-relaxed">
                A unified view of your legal options, timeline realities, and required evidence to regain your digital sovereignty.
            </p>
        </div>
      </div>

      {/* Merged Timeline Section */}
      <div className="p-8 border-b border-neutral-700 bg-neutral-900/10">
        <div className="flex items-center gap-3 mb-6">
            <div className="w-1.5 h-6 bg-yellow-500 rounded-full"></div>
            <h4 className="text-xs font-black text-gray-200 uppercase tracking-widest">Justice System Timeline Reality (Est.)</h4>
        </div>
        <div className="h-[450px]">
            <TimelineChart />
        </div>
      </div>

      {/* CASE STUDY SUBSECTION */}
      <div className="p-8 border-b border-neutral-700 bg-green-900/5">
        <SuccessStory />
      </div>

      {/* Dual Path Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Civil Path */}
        <div className="p-10 border-b lg:border-b-0 lg:border-r border-neutral-700 bg-cyan-900/5 relative">
          <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
             </svg>
          </div>
          <span className="inline-block px-3 py-1 bg-cyan-600/20 text-cyan-400 text-[10px] font-black uppercase tracking-widest rounded border border-cyan-500/20 mb-6">
            Civil Intervention
          </span>
          <h4 className="text-3xl font-black text-white uppercase tracking-tight mb-4 leading-none">Urgent Relief</h4>
          <p className="text-gray-300 mb-8 text-sm leading-relaxed font-medium">
            This is the fastest legal mechanism available. It requires strict procedural rigor to obtain a Protection Order (Interdict) to compel content removal.
          </p>
          <ul className="space-y-6 relative z-10">
            <li className="flex items-start group">
                <div className="mt-1 w-10 h-10 flex-shrink-0 flex items-center justify-center bg-neutral-900 raised-card rounded-lg text-cyan-400 group-hover:border-cyan-400 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <div className="ml-5">
                    <span className="block text-sm font-black text-white uppercase tracking-tight mb-1">Founding Affidavit</span>
                    <span className="text-xs text-gray-400 leading-snug block font-medium">Drafting formal court papers with forensic digital evidence securely attached as annexures.</span>
                </div>
            </li>
            <li className="flex items-start group">
                <div className="mt-1 w-10 h-10 flex-shrink-0 flex items-center justify-center bg-neutral-900 raised-card rounded-lg text-cyan-400 group-hover:border-cyan-400 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m3-4h1m-1 4h1m-1 4h1m-1 4h1m-1 4h1m-1 4h1" />
                    </svg>
                </div>
                <div className="ml-5">
                    <span className="block text-sm font-black text-white uppercase tracking-tight mb-1">Ex-Parte Application</span>
                    <span className="text-xs text-gray-400 leading-snug block font-medium">Appearing before a Magistrate to argue the extreme urgency of the digital threat.</span>
                </div>
            </li>
          </ul>
        </div>

        {/* Criminal Path */}
        <div className="p-10 bg-yellow-900/5 relative">
          <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.2-2.858.59-4.181m-3.236 5.714A21.88 21.88 0 003 15.364" />
             </svg>
          </div>
          <span className="inline-block px-3 py-1 bg-yellow-600/20 text-yellow-500 text-[10px] font-black uppercase tracking-widest rounded border border-yellow-500/20 mb-6">
            Criminal Justice
          </span>
          <h4 className="text-3xl font-black text-white uppercase tracking-tight mb-4 leading-none">Prosecution</h4>
          <p className="text-gray-300 mb-8 text-sm leading-relaxed font-medium">
            A long-term strategy to secure a permanent criminal record. Relies on the Cybercrimes Act (Section 17) and forensic persistence.
          </p>

          {/* SAPS REALITY CHECK */}
          <div className="mb-8 p-5 bg-red-900/10 border border-red-500/30 rounded-xl raised-card !bg-opacity-20">
             <h5 className="text-red-400 font-black uppercase text-[10px] tracking-widest mb-2 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                Operational Reality Check
             </h5>
             <p className="text-xs text-gray-200 leading-relaxed font-medium">
                The SAPS is currently navigating an 8,000+ detective vacancy crisis. Combined with forensic backlogs, this generates extreme <strong>court delays</strong>. Persistence and weekly follow-ups are the only way to ensure your docket remains active.
             </p>
          </div>

          <ul className="space-y-6 relative z-10">
            <li className="flex items-start group">
                <div className="mt-1 w-10 h-10 flex-shrink-0 flex items-center justify-center bg-neutral-900 raised-card rounded-lg text-yellow-500 group-hover:border-yellow-500 transition-colors">
                    {/* Police Car Icon */}
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 11h16m-2 0a2 2 0 012 2v3H4v-3a2 2 0 012-2m2 0V9a2 2 0 012-2h4a2 2 0 012 2v2M6 16v1a1 1 0 001 1h1a1 1 0 001-1v-1m8 0v1a1 1 0 001 1h1a1 1 0 001-1v-1M9 7h6M11 5h2" />
                    </svg>
                </div>
                <div className="ml-5">
                    <span className="block text-sm font-black text-white uppercase tracking-tight mb-1">Docket Initiation</span>
                    <span className="text-xs text-gray-400 leading-snug block font-medium">Securing your CAS number and identifying a dedicated Investigating Officer (IO) at your local station.</span>
                </div>
            </li>
            <li className="flex items-start group">
                <div className="mt-1 w-10 h-10 flex-shrink-0 flex items-center justify-center bg-neutral-900 raised-card rounded-lg text-yellow-500 group-hover:border-yellow-500 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <div className="ml-5">
                    <span className="block text-sm font-black text-white uppercase tracking-tight mb-1">Forensic Phase</span>
                    <span className="text-xs text-gray-400 leading-snug block font-medium">Gathering digital footprints, ISP subpoenas, and suspect interviews under the Cybercrimes Act.</span>
                </div>
            </li>
          </ul>
        </div>
      </div>

      {/* Integrated Evidence Report */}
      <div className="bg-[#262626] border-t border-neutral-700 p-8 shadow-inner">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
            <div className="md:col-span-1">
                <h3 className="text-lg font-black text-white uppercase tracking-tight mb-6 flex items-center gap-3">
                    <div className="w-1.5 h-6 bg-cyan-400 rounded-full"></div>
                    Forensic Proof
                </h3>
                
                <div className="space-y-4">
                    <div className="bg-red-900/10 border border-red-900/30 p-5 rounded-lg raised-card !bg-opacity-20 border-opacity-30">
                        <h4 className="text-red-400 text-[10px] font-black uppercase tracking-widest mb-2">Non-Compliant (Screenshots)</h4>
                        <p className="text-gray-400 text-xs leading-relaxed font-medium">
                            Screenshots lack the "Source Metadata" required for legal verification and cannot be hashed to block future uploads globally.
                        </p>
                    </div>

                    <button 
                        onClick={handleHashingClick}
                        className="w-full text-left bg-green-900/10 border border-green-900/30 p-5 rounded-lg raised-card !bg-opacity-20 border-opacity-30 group hover:border-green-500/50 hover:bg-green-900/20 transition-all cursor-pointer"
                    >
                        <div className="flex justify-between items-center mb-2">
                             <h4 className="text-green-400 text-[10px] font-black uppercase tracking-widest">Compliant (Hashing)</h4>
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 opacity-50 group-hover:opacity-100 group-hover:translate-x-1 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                        </div>
                        <p className="text-gray-400 text-xs leading-relaxed font-medium group-hover:text-gray-300">
                            <strong>Hashing</strong> creates a unique "Digital Fingerprint" directly on your device to block content across global platforms without sharing it.
                            <br/>
                            <span className="text-[9px] text-green-500 uppercase tracking-widest mt-2 block underline">Read the Guide</span>
                        </p>
                    </button>
                </div>
            </div>
            <div className="md:col-span-2">
                <EvidenceChart />
            </div>
        </div>
        
        <ActionLog />
      </div>
    </section>
  );
};