import React from 'react';

export const ScamAwareness: React.FC = () => {
  return (
    <section className="mb-16 raised-card rounded-2xl p-8 md:p-12 bg-[#1C1C1C] border-t-4 border-red-500 relative overflow-hidden">
      <div className="text-center mb-10">
        <span className="text-red-500 font-black tracking-[0.2em] uppercase text-[10px] mb-2 block">Counter-Intelligence</span>
        <h2 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tight">Social Engineering Defense</h2>
        <div className="h-1 w-20 bg-red-500 mx-auto mt-4 mb-3 rounded-full opacity-50"></div>
        <p className="text-gray-400 max-w-2xl mx-auto text-sm font-medium">
          The platform isn't the vulnerability. You are. Hardening your human firewall against the three most common attack vectors in SA.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* WhatsApp Strategy */}
        <div className="raised-tile p-6 bg-[#262626] border-l-4 border-green-500 group hover:-translate-y-1 transition-transform">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center text-green-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                </div>
                <h3 className="text-white font-black uppercase text-lg">WhatsApp</h3>
            </div>
            <div className="space-y-4">
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-green-500 font-bold text-xs uppercase mb-1">The "Code" Heist</h4>
                    <p className="text-xs text-gray-400"><strong>Scenario:</strong> "I sent you a code by mistake, please send it back."</p>
                    <p className="text-xs text-gray-400 mt-1"><strong>Reality:</strong> That code logs them into YOUR account. Never share a 6-digit SMS code.</p>
                </div>
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-green-500 font-bold text-xs uppercase mb-1">Defense Protocol</h4>
                    <p className="text-xs text-gray-400">Settings &gt; Account &gt; <strong>Two-Step Verification</strong>. Set a PIN. Without this PIN, the SMS code is useless to them.</p>
                </div>
            </div>
        </div>

        {/* Facebook Strategy */}
        <div className="raised-tile p-6 bg-[#262626] border-l-4 border-blue-500 group hover:-translate-y-1 transition-transform">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>
                </div>
                <h3 className="text-white font-black uppercase text-lg">Facebook</h3>
            </div>
            <div className="space-y-4">
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-blue-500 font-bold text-xs uppercase mb-1">Marketplace Ghosts</h4>
                    <p className="text-xs text-gray-400"><strong>Scenario:</strong> "I'll send a courier with cash (FedEx/Aramex) but need insurance fee first."</p>
                    <p className="text-xs text-gray-400 mt-1"><strong>Reality:</strong> Couriers do not carry cash for buyers. It is always a phishing script.</p>
                </div>
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-blue-500 font-bold text-xs uppercase mb-1">Profile Cloning</h4>
                    <p className="text-xs text-gray-400">If a "friend" adds you again, check the profile URL. If it has numbers at the end or was created today, block immediately.</p>
                </div>
            </div>
        </div>

        {/* Telegram Strategy */}
        <div className="raised-tile p-6 bg-[#262626] border-l-4 border-cyan-500 group hover:-translate-y-1 transition-transform">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20.665 3.717l-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"/></svg>
                </div>
                <h3 className="text-white font-black uppercase text-lg">Telegram</h3>
            </div>
            <div className="space-y-4">
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-cyan-500 font-bold text-xs uppercase mb-1">The Crypto Admin</h4>
                    <p className="text-xs text-gray-400"><strong>Scenario:</strong> An "Admin" DMs you to "validate your wallet" or offer support.</p>
                    <p className="text-xs text-gray-400 mt-1"><strong>Reality:</strong> Admins NEVER DM first. Check the username handle carefully (e.g., @Support_1 vs @Support).</p>
                </div>
                <div className="bg-black/30 p-3 rounded border border-white/5">
                    <h4 className="text-cyan-500 font-bold text-xs uppercase mb-1">Privacy Settings</h4>
                    <p className="text-xs text-gray-400">Set "Who can see my phone number" to <strong>Nobody</strong>. This prevents strangers from scraping your real identity.</p>
                </div>
            </div>
        </div>

      </div>
    </section>
  );
};