import React from 'react';

const TESTIMONIALS = [
  {
    client: "Family Kitchen",
    role: "Owner",
    quote: "We went from relying on Facebook algorithms to owning our traffic. The results were immediate. No ads, just smart structure.",
    metric: "1,172% Growth",
    color: "text-green-500",
    border: "border-green-500"
  },
  {
    client: "Tsumkwe Net",
    role: "Technical Lead",
    quote: "Securing a R45k contract three weeks after launch was proof enough. WMC understands industrial business needs.",
    metric: "R45k Win",
    color: "text-[#D4AF37]",
    border: "border-[#D4AF37]"
  },
  {
    client: "Luminaire Aesthetics",
    role: "Director",
    quote: "My clients value privacy. WMC built a digital presence that screams 'expert' without compromising discretion.",
    metric: "Elite Status",
    color: "text-purple-500",
    border: "border-purple-500"
  },
  {
    client: "E-Light Media",
    role: "Creative Director",
    quote: "The perfect technical partner. They handle the heavy lifting on infrastructure so we can focus on pure creative.",
    metric: "24+ Months",
    color: "text-[#00AACC]",
    border: "border-[#00AACC]"
  }
];

export const Testimonials: React.FC = () => {
  return (
    <section className="py-12 border-t border-white/5">
        <div className="text-center mb-10">
            <span className="text-gray-500 font-black uppercase tracking-[0.2em] text-[10px] mb-2 block">Direct Transmissions</span>
            <h3 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight">Client Intel</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TESTIMONIALS.map((t, idx) => (
                <div key={idx} className={`raised-card p-6 bg-[#1C1C1C] border-l-2 ${t.border} hover:bg-[#262626] transition-colors group`}>
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h4 className="text-white font-bold uppercase text-sm">{t.client}</h4>
                            <span className="text-[10px] text-gray-500 uppercase tracking-widest">{t.role}</span>
                        </div>
                        <span className={`text-[10px] font-black uppercase tracking-widest ${t.color} border border-white/10 px-2 py-1 rounded group-hover:bg-white/5`}>{t.metric}</span>
                    </div>
                    <p className="text-gray-300 text-xs md:text-sm leading-relaxed italic">
                        "{t.quote}"
                    </p>
                </div>
            ))}
        </div>
    </section>
  );
};