import React from 'react';

interface HomeValuePropsProps {
    onNavigate: (page: string) => void;
}

export const HomeValueProps: React.FC<HomeValuePropsProps> = ({ onNavigate }) => {
  return (
    <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="text-center mb-12">
            <span className="text-gray-500 font-black tracking-[0.2em] uppercase text-[10px] mb-2 block">Our Belief</span>
            <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tight">
                Own Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">Name</span>
            </h2>
            <div className="h-1 w-20 bg-[#D4AF37] mx-auto mt-6 mb-6 rounded-full"></div>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg leading-relaxed">
                We don't just build websites; we build assets for you. We don't just delete bad posts; we protect your name. WMC helps you attack with tech and defend with law.
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Card 1: Infrastructure */}
            <div className="raised-card p-8 bg-[#1C1C1C] hover:-translate-y-2 transition-transform duration-300 group">
                <div className="w-14 h-14 bg-[#00AACC]/10 rounded-xl flex items-center justify-center text-[#00AACC] mb-6 group-hover:bg-[#00AACC] group-hover:text-black transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m3-4h1m-1 4h1m-1 4h1m-1 4h1m-1 4h1m-1 4h1" /></svg>
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight mb-3">Your Own Website</h3>
                <p className="text-sm text-gray-400 leading-relaxed mb-6">
                    Stop paying monthly fees to Wix or Shopify. We build fast websites on Google that you own forever. No rent. No debt. Just yours.
                </p>
                <button onClick={() => onNavigate('solutions')} className="text-[#00AACC] text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-3 transition-all">
                    View Options <span className="text-lg leading-none">&rarr;</span>
                </button>
            </div>

            {/* Card 2: Defense */}
            <div className="raised-card p-8 bg-[#1C1C1C] hover:-translate-y-2 transition-transform duration-300 group border-t-4 border-t-red-600">
                <div className="w-14 h-14 bg-red-600/10 rounded-xl flex items-center justify-center text-red-500 mb-6 group-hover:bg-red-600 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight mb-3">Fight Back</h3>
                <p className="text-sm text-gray-400 leading-relaxed mb-6">
                    When someone attacks your name online, being silent doesn't work. We use legal court orders and tech skills to remove bad content and find out who did it.
                </p>
                <button onClick={() => onNavigate('guide')} className="text-red-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-3 transition-all">
                    Get Help Now <span className="text-lg leading-none">&rarr;</span>
                </button>
            </div>

            {/* Card 3: The Syndicate */}
            <div className="raised-card p-8 bg-[#1C1C1C] hover:-translate-y-2 transition-transform duration-300 group">
                <div className="w-14 h-14 bg-[#D4AF37]/10 rounded-xl flex items-center justify-center text-[#D4AF37] mb-6 group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight mb-3">Learn & Earn</h3>
                <p className="text-sm text-gray-400 leading-relaxed mb-6">
                    Join our team. We teach you how to build websites, make them appear on Google, and make money from them. Earn while you learn.
                </p>
                <button onClick={() => onNavigate('learn-earn')} className="text-[#D4AF37] text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-3 transition-all">
                    Join The Team <span className="text-lg leading-none">&rarr;</span>
                </button>
            </div>

        </div>
    </section>
  );
};