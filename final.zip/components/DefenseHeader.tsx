
import React from 'react';

export const DefenseHeader: React.FC = () => {
  return (
    <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 mb-12 no-print">
      <div className="relative h-[350px] md:h-[450px] rounded-3xl overflow-hidden raised-card border-none bg-purple-900 group">
        
        {/* User Image Integration with Unsplash Fallback */}
        <img 
            src="/assets/enough-is-enough.jpg" // Place your image here
            onError={(e) => {
                // Fallback to a relevant stock image if local file is missing
                // Optimized Unsplash URL: WebP format, Cropped, Quality 80
                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1635338601550-994266c2436d?auto=format&fit=crop&q=80&w=1920"; 
            }}
            alt="Stop GBV - Enough is Enough"
            className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay grayscale hover:grayscale-0 transition-all duration-700 scale-105"
            // LCP Optimizations for Hero Image
            loading="eager"
            fetchPriority="high"
            decoding="sync"
        />

        {/* Background Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900 via-purple-900/80 to-purple-900/40"></div>
        
        {/* Content Container */}
        <div className="absolute inset-0 flex flex-col justify-center p-8 md:p-16 max-w-4xl relative z-10">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-purple-950/80 border border-purple-400/30 rounded-full mb-6 backdrop-blur-sm w-fit shadow-lg">
            <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse"></span>
            <span className="text-[10px] font-black uppercase tracking-[0.1em] text-purple-200">National Awareness Protocol</span>
          </div>
          
          {/* Main Heading */}
          <h2 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-6 drop-shadow-2xl">
            Enough Is <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-white">Enough.</span>
          </h2>
          
          {/* Enhanced Subtext/Description */}
          <div className="max-w-xl space-y-4">
              <p className="text-sm md:text-lg text-purple-100 font-medium leading-relaxed drop-shadow-lg border-l-4 border-purple-400 pl-4">
                The "Enough is Enough" campaign is a call to action against Gender-Based Violence. This guide operationalizes that sentiment, turning passive support into active, legal, and technical defense.
              </p>
              <p className="text-xs md:text-sm text-purple-300 font-medium leading-relaxed">
                We provide the tools to stop the cycle of digital abuse. Every digital footprint of abuse violates your dignity. Use this protocol to fight back, save the truth, and take back control.
              </p>
          </div>

        </div>
      </div>
    </div>
  );
};
