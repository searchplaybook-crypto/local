import React from 'react';

export const HomeSocialProof: React.FC = () => {
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 no-print">
        <div className="bg-[#262626] border-y border-white/5 md:border md:rounded-xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-8 md:gap-4 shadow-lg">
            
            {/* Stat 1 */}
            <div className="text-center md:text-left flex-1 border-b md:border-b-0 md:border-r border-white/10 pb-6 md:pb-0 md:pr-6 w-full md:w-auto">
                <span className="block text-3xl font-black text-white mb-1">1,172%</span>
                <span className="text-[10px] uppercase tracking-widest text-[#00AACC] font-bold">Client Growth</span>
                <p className="text-xs text-gray-500 mt-2 leading-snug">
                    Real business growth for "Family Kitchen" without paying for ads.
                </p>
            </div>

            {/* Stat 2 */}
            <div className="text-center md:text-left flex-1 border-b md:border-b-0 md:border-r border-white/10 pb-6 md:pb-0 md:px-6 w-full md:w-auto">
                <span className="block text-3xl font-black text-white mb-1">48 Hrs</span>
                <span className="text-[10px] uppercase tracking-widest text-green-500 font-bold">Removal Speed</span>
                <p className="text-xs text-gray-500 mt-2 leading-snug">
                    Average time to remove illegal content using Court Orders.
                </p>
            </div>

            {/* Stat 3 */}
            <div className="text-center md:text-left flex-1 md:pl-6 w-full md:w-auto">
                <span className="block text-3xl font-black text-white mb-1">100%</span>
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-bold">Ownership</span>
                <p className="text-xs text-gray-500 mt-2 leading-snug">
                    You own the website. You don't pay rent. No hidden technical problems.
                </p>
            </div>

        </div>
    </div>
  );
};