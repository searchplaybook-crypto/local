import React from 'react';

export const SupportNetwork: React.FC = () => {
  return (
    <section id="support-network" className="raised-card rounded-2xl p-8 md:p-14 text-white relative overflow-hidden mb-16 bg-[#1C1C1C]">
      
      <div className="relative z-10 max-w-6xl mx-auto">
        <div className="text-center mb-12">
            <span className="text-cyan-400 font-black text-[10px] uppercase tracking-widest block mb-2">We Are Together</span>
            <h2 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tight mb-2">National Support Network</h2>
            <div className="h-1 w-20 bg-yellow-500 mx-auto rounded-full opacity-50 mb-4"></div>
            <p className="text-gray-400 text-sm max-w-2xl mx-auto">
                You do not have to fight this alone. These organizations are trained to help you right now.
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* GBV Command Centre */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-yellow-500/50 transition-colors group">
                <h3 className="text-yellow-500 font-black uppercase text-lg mb-1">GBV Command Centre</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">24/7 Counseling & Support</p>
                <div className="space-y-3">
                    <a href="tel:0800428428" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-yellow-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                        0800 428 428
                    </a>
                    <a href="sms:*120*7867#" className="flex items-center gap-3 text-gray-300 text-sm bg-black/30 p-3 rounded hover:bg-white/10 transition-colors">
                        <span className="font-bold">USSD:</span> *120*7867#
                    </a>
                </div>
            </div>

            {/* SAPS */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-blue-500/50 transition-colors group">
                <h3 className="text-blue-500 font-black uppercase text-lg mb-1">SAPS Emergency</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">Police & Crime Reporting</p>
                <div className="space-y-3">
                    <a href="tel:10111" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-blue-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                        10111
                    </a>
                    <span className="flex items-center gap-3 text-gray-400 text-sm bg-black/30 p-3 rounded">
                        <span>Ask for <strong>FCS Unit</strong> (Family Violence)</span>
                    </span>
                </div>
            </div>

            {/* Childline */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-green-500/50 transition-colors group">
                <h3 className="text-green-500 font-black uppercase text-lg mb-1">Childline SA</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">Under 18 Support</p>
                <div className="space-y-3">
                    <a href="tel:116" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-green-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        116 (Free Call)
                    </a>
                </div>
            </div>

            {/* Suicide Crisis */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-red-500/50 transition-colors group">
                <h3 className="text-red-500 font-black uppercase text-lg mb-1">Suicide Crisis Line</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">SADAG (Mental Health)</p>
                <div className="space-y-3">
                    <a href="tel:0800567567" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-red-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
                        0800 567 567
                    </a>
                </div>
            </div>

            {/* Legal Aid */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-cyan-500/50 transition-colors group">
                <h3 className="text-cyan-500 font-black uppercase text-lg mb-1">Legal Aid SA</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">Free Legal Advice</p>
                <div className="space-y-3">
                    <a href="tel:0800110110" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-cyan-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
                        0800 110 110
                    </a>
                </div>
            </div>

            {/* Tears Foundation */}
            <div className="bg-[#262626] border border-neutral-700 p-6 rounded-xl hover:border-purple-500/50 transition-colors group">
                <h3 className="text-purple-500 font-black uppercase text-lg mb-1">TEARS Foundation</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-4">Help Near You</p>
                <div className="space-y-3">
                    <a href="tel:*134*7355#" className="flex items-center gap-3 text-white font-bold bg-black/30 p-3 rounded hover:bg-purple-500 hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /></svg>
                        Dial *134*7355#
                    </a>
                    <p className="text-xs text-gray-500 italic">Locates nearest service centers</p>
                </div>
            </div>

        </div>
      </div>
    </section>
  );
};