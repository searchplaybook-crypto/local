
import React from 'react';
import { PageHero } from './PageHero';
import { ServiceCard } from './ServiceCard';
import { PricingBlock } from './PricingBlock';
import { CMS } from '../constants';
import { SEO } from './SEO';

export const Solutions: React.FC = () => {
  const content = CMS.pages.solutions;
  const services = CMS.services;

  return (
    <div className="animate-fade-in pb-12">
      <SEO title={content.title} description={content.description} />
      <PageHero 
        title={content.title}
        tagline={content.tagline} 
        image={content.heroImage}
      />

      {/* Audit Services */}
      <section className="mb-20">
        <div className="flex items-center gap-4 mb-8">
          <div className="h-px bg-white/10 flex-grow"></div>
          <h2 className="text-[#D4AF37] font-black uppercase tracking-widest text-sm">Audit Services</h2>
          <div className="h-px bg-white/10 flex-grow"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {services.audit.map((s) => (
            <div key={s.id} className="p-8 bg-[#1C1C1C] border border-white/10 rounded-xl flex justify-between items-center hover:border-[#D4AF37] hover:shadow-[0_0_15px_rgba(212,175,55,0.2)] transition-all group">
              <div>
                <h3 className="text-xl font-black text-white uppercase mb-1">{s.title}</h3>
                <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Diagnostic</span>
              </div>
              <div className="text-right">
                <span className="block text-2xl font-black text-[#D4AF37]">{s.price}</span>
                <span className="text-[10px] text-gray-500 font-bold uppercase">{s.frequency}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Service Range Catalogue */}
      <section className="mb-20">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-black text-white uppercase tracking-tight">Service Range</h2>
          <p className="text-gray-400 text-sm mt-2">Comprehensive digital modules.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.catalogue.map((s, idx) => (
            <ServiceCard 
              key={idx}
              title={s.title}
              price={s.price}
              frequency={s.frequency}
              description={s.description}
            />
          ))}
        </div>
      </section>

      {/* Set & Forget Options */}
      <section className="mb-12">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-black text-white uppercase tracking-tight">Set & Forget</h2>
          <p className="text-gray-400 text-sm mt-2">Automated infrastructure tiers.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.setAndForget.map((s) => (
            <PricingBlock 
              key={s.id}
              title={s.title}
              price={s.price}
              frequency={s.frequency}
              tier={s.tier}
              description={s.description}
              highlight={s.highlight}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
