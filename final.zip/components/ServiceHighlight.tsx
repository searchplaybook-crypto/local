
import React, { useState } from 'react';

export const ServiceHighlight: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'problem' | 'solution' | 'result'>('problem');

  const steps = [
    { id: 'problem', label: 'The Problem' },
    { id: 'solution', label: 'The Fix' },
    { id: 'result', label: 'The Win' }
  ];

  const content = {
    problem: {
      title: "The Trap: Digital Rent",
      description: "Most businesses pay monthly fees for websites they don't own. If you stop paying Wix, Shopify, or a developer, you disappear. You are renting your existence.",
      color: "text-red-500",
      borderColor: "border-red-500",
      bgGlow: "bg-red-500/10"
    },
    solution: {
      title: "The Fix: Sovereign Code",
      description: "We build 'Website For Life' infrastructure. Hosted on Google. You pay once. You own the code 100%. No monthly hosting fees. Zero debt.",
      color: "text-[#00AACC]",
      borderColor: "border-[#00AACC]",
      bgGlow: "bg-[#00AACC]/10"
    },
    result: {
      title: "The Win: Permanent Asset",
      description: "A fast, secure asset that ranks #1. You focus on your business, while your digital infrastructure runs for free, forever.",
      color: "text-[#D4AF37]",
      borderColor: "border-[#D4AF37]",
      bgGlow: "bg-[#D4AF37]/10"
    }
  };

  const activeContent = content[activeTab];

  const scrollToAudit = () => {
      const form = document.getElementById('contact-form');
      if (form) form.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="mb-20 py-8">
       <div className="max-w-4xl mx-auto">
           {/* Header */}
           <div className="text-center mb-8">
                <span className="text-[#00AACC] font-black uppercase tracking-[0.2em] text-[10px] mb-2 block">How It Works</span>
           </div>

           {/* Navigation Bubbles */}
           <div className="flex justify-center items-center gap-4 mb-8">
               {steps.map((step, idx) => (
                   <div key={step.id} className="flex items-center">
                       <button
                           onClick={() => setActiveTab(step.id as any)}
                           className={`
                               px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest transition-all duration-300 border
                               ${activeTab === step.id 
                                   ? `bg-white text-black border-white shadow-[0_0_20px_rgba(255,255,255,0.4)] scale-105` 
                                   : 'bg-[#1C1C1C] text-gray-500 border-neutral-800 hover:border-gray-600'}
                           `}
                       >
                           {step.label}
                       </button>
                       {idx < steps.length - 1 && (
                           <div className="w-8 h-px bg-neutral-800 hidden sm:block mx-2"></div>
                       )}
                   </div>
               ))}
           </div>

           {/* Content Card */}
           <div className={`raised-card rounded-2xl p-8 md:p-12 bg-[#1C1C1C] border-t-4 transition-all duration-500 ${activeContent.borderColor} relative overflow-hidden text-center`}>
               <div className={`absolute inset-0 opacity-5 ${activeContent.bgGlow} transition-colors duration-500`}></div>
               
               <div className="relative z-10 animate-fade-in" key={activeTab}>
                   <h3 className={`text-3xl md:text-4xl font-black uppercase tracking-tighter mb-4 ${activeContent.color}`}>
                       {activeContent.title}
                   </h3>
                   <p className="text-gray-400 text-lg leading-relaxed max-w-2xl mx-auto mb-8">
                       {activeContent.description}
                   </p>
                   
                   <button 
                        onClick={scrollToAudit}
                        className="group inline-flex items-center gap-3 bg-white text-black px-8 py-4 rounded-lg font-black uppercase text-xs tracking-widest hover:bg-gray-200 transition-colors shadow-lg"
                   >
                       Get A Free Audit
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                   </button>
               </div>
           </div>
       </div>
    </section>
  );
};
