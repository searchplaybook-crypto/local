import React, { useState, useEffect } from 'react';
import { CMS } from '../constants';

interface HeaderProps {
  activeTab?: string;
  onNavigate?: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (tab: string) => {
    onNavigate?.(tab);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-[1001] bg-[#111111]/95 backdrop-blur-md border-b border-white/5 h-20 no-print">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        
        {/* LOGO */}
        <button 
          className="flex items-center gap-3 cursor-pointer group" 
          onClick={() => handleNav('home')}
        >
          <div className="w-10 h-12 bg-[#D4AF37] flex flex-col items-center justify-center pt-1 border-b-2 border-black/50 shadow-lg rounded-t-md rounded-b-[2rem] group-hover:scale-105 transition-transform">
            <span className="text-black text-[10px] font-black leading-none">{CMS.identity.short}</span>
          </div>
          <div className="hidden sm:flex flex-col justify-center">
              <span className="text-white font-black text-sm tracking-tighter uppercase leading-none">{CMS.identity.full}</span>
          </div>
        </button>

        {/* DESKTOP NAV */}
        <div className="hidden min-[960px]:flex items-center gap-1 ml-4">
          {CMS.nav.map((item) => (
            <button 
              key={item.id} 
              onClick={() => handleNav(item.id)} 
              className={`text-[10px] font-black uppercase tracking-[0.15em] px-4 py-2 transition-colors ${activeTab === item.id ? 'text-[#D4AF37]' : 'text-gray-400 hover:text-white'}`}
            >
              {item.title}
            </button>
          ))}
        </div>

        {/* MOBILE TOGGLE */}
        <button 
            className="min-[960px]:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
            <span className={`block w-6 h-0.5 bg-[#D4AF37] transition-all ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`}></span>
            <span className={`block w-6 h-0.5 bg-[#D4AF37] transition-all ${mobileMenuOpen ? 'opacity-0' : ''}`}></span>
            <span className={`block w-6 h-0.5 bg-[#D4AF37] transition-all ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}></span>
        </button>
      </div>

      {/* MOBILE DRAWER */}
      {mobileMenuOpen && (
          <div className="fixed inset-0 bg-[#111] z-40 pt-24 px-6 overflow-y-auto animate-fade-in flex flex-col min-[960px]:hidden">
              {CMS.nav.map((item) => (
                <button 
                  key={item.id} 
                  onClick={() => handleNav(item.id)} 
                  className={`py-5 text-left text-xl font-black uppercase border-b border-white/10 ${activeTab === item.id ? 'text-[#D4AF37]' : 'text-white'}`}
                >
                    {item.title}
                </button>
              ))}
          </div>
      )}
    </nav>
  );
};