import React, { useState } from 'react';

export const SecureHasher: React.FC = () => {
  const [input, setInput] = useState('');
  const [hash, setHash] = useState('');

  const generateHash = async () => {
    if (!input) return;
    const msgBuffer = new TextEncoder().encode(input);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    setHash(hashHex);
  };

  return (
    <section id="hashing-explained" className="raised-card p-8 bg-[#1C1C1C] border-l-4 border-[#D4AF37] mb-16 rounded-xl">
        <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1">
                <span className="text-[#D4AF37] font-black uppercase tracking-[0.2em] text-[10px] mb-2 block">Live Tool</span>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-2">Digital Fingerprinting</h3>
                <p className="text-sm text-gray-400 mb-6 leading-relaxed">
                    Experience how hashing works locally on your device. Enter a text phrase below (e.g., a threat message) to generate its unique SHA-256 signature. 
                    <br/><br/>
                    <strong className="text-white">Note:</strong> Nothing is sent to a server. This calculation happens 100% in your browser.
                </p>
                <div className="space-y-4">
                    <textarea 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Enter text to hash..."
                        className="w-full bg-black/30 border border-neutral-700 rounded-lg p-4 text-white text-sm focus:border-[#D4AF37] focus:outline-none transition-colors"
                        rows={3}
                    />
                    <button 
                        onClick={generateHash}
                        className="bg-[#D4AF37] text-black font-black uppercase text-xs px-6 py-3 rounded shadow-[0_0_15px_rgba(212,175,55,0.5)] hover:shadow-[0_0_25px_rgba(212,175,55,0.8)] hover:bg-white transition-all"
                    >
                        Generate Hash
                    </button>
                </div>
            </div>
            <div className="flex-1 bg-black/50 rounded-lg p-6 border border-white/5 flex flex-col justify-center min-h-[200px]">
                <span className="text-gray-500 text-[10px] uppercase tracking-widest font-bold mb-2">SHA-256 Output</span>
                <div className="font-mono text-xs text-[#00AACC] break-all leading-relaxed bg-[#111] p-4 rounded border border-white/5">
                    {hash || <span className="text-gray-600 italic">Waiting for input...</span>}
                </div>
            </div>
        </div>
    </section>
  );
};