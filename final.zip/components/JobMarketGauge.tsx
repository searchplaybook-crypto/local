
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const MARKET_DATA = [
  { name: 'Service Demand', value: 85, color: '#D4AF37' },
  { name: 'Available Pros', value: 20, color: '#404040' },
  { name: 'Your Opportunity', value: 95, color: '#00AACC' },
];

export const JobMarketGauge: React.FC = () => {
  return (
    <div className="animate-fade-in py-12 space-y-12">
        <div className="text-center space-y-6 mb-12">
            <span className="text-[#D4AF37] font-black uppercase tracking-[0.3em] text-xs">Market Intelligence</span>
            <h2 className="text-5xl md:text-7xl font-black uppercase text-white tracking-tighter">
                Job Market <span className="text-[#D4AF37]">Gauge</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg leading-relaxed">
                The data is clear. South African businesses are desperate for digital infrastructure, but the market is flooded with amateurs. The gap is your profit.
            </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Chart */}
            <div className="raised-card p-8 bg-[#1C1C1C] h-[400px] flex flex-col">
                <h3 className="text-white font-black uppercase tracking-tight mb-6">Gap Analysis: Digital Services SA</h3>
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={MARKET_DATA} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={120} tick={{fill: '#fff', fontSize: 12, fontWeight: 700}} axisLine={false} tickLine={false} />
                        <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{backgroundColor: '#111', border: '1px solid #333'}} />
                        <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={40}>
                            {MARKET_DATA.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* Insight Text */}
            <div className="space-y-8">
                <div className="space-y-4">
                    <h4 className="text-2xl font-black text-white uppercase tracking-tight">The "Provider" Problem</h4>
                    <p className="text-gray-400 leading-relaxed text-sm">
                        In places like Bloemfontein and Kimberly, service providers are hardworking but digitally invisible. They don't care about devices. They rely on word of mouth, which is dying.
                    </p>
                </div>
                
                <div className="space-y-4">
                    <h4 className="text-2xl font-black text-[#00AACC] uppercase tracking-tight">The Search Mafia Solution</h4>
                    <p className="text-gray-400 leading-relaxed text-sm">
                        You bridge the gap. You don't need to do the work. You just need to connect the business to our infrastructure. We handle the code, the SEO, and the reputation. You take the commission.
                    </p>
                </div>

                <div className="p-6 border-l-4 border-[#D4AF37] bg-[#D4AF37]/5">
                    <p className="text-[#D4AF37] font-bold text-sm uppercase tracking-wide">
                        "In real, you'll get a commission and we'll pay within three days of the finalized deal."
                    </p>
                </div>
            </div>
        </div>
    </div>
  );
};
