
import React from 'react';
import { CMS } from '../constants';

interface SearchMafiaHubProps {
    onNavigate: (page: string) => void;
}

export const SearchMafiaHub: React.FC<SearchMafiaHubProps> = ({ onNavigate }) => {
    return (
        <div className="animate-fade-in py-12 space-y-20">
            {/* 1. HERO SECTION */}
            <div className="relative w-full rounded-3xl overflow-hidden raised-card border-none bg-neutral-900 group h-[450px]">
                <div className="absolute inset-0 w-full h-full">
                    <img 
                        src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&q=80&w=1920"
                        alt="The Syndicate"
                        className="w-full h-full object-cover opacity-30 group-hover:opacity-40 transition-opacity duration-700 filter grayscale contrast-125"
                    />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/40 to-transparent"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-[#111] via-[#111]/70 to-transparent"></div>

                <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16 max-w-4xl relative z-10">
                    <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-full mb-6 backdrop-blur-sm w-fit">
                        <span className="w-1.5 h-1.5 rounded-full animate-pulse bg-[#D4AF37]"></span>
                        <span className="text-[10px] font-black uppercase tracking-[0.1em] text-[#D4AF37]">The Syndicate</span>
                    </div>
                    <h2 className="text-5xl md:text-8xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-6">
                        Community <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] to-yellow-600">Hub</span>
                    </h2>
                    <p className="text-gray-300 text-lg font-medium leading-relaxed max-w-2xl mb-10">
                        {CMS.syndicate.intro}
                    </p>
                    
                    <div className="flex flex-wrap gap-4">
                        <button 
                            onClick={() => onNavigate('mafia/membership')} 
                            className="bg-[#D4AF37] text-black font-black uppercase text-xs py-4 px-8 rounded-lg hover:bg-white transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.4)]"
                        >
                            Join Syndicate
                        </button>
                        <button 
                            onClick={() => onNavigate('mafia/academy')} 
                            className="border border-[#00AACC] text-[#00AACC] bg-[#00AACC]/10 font-black uppercase text-xs py-4 px-8 rounded-lg hover:bg-[#00AACC] hover:text-black transition-all backdrop-blur-sm"
                        >
                            Enter Academy
                        </button>
                    </div>
                </div>
            </div>

            {/* 2. THE PROTOCOL */}
            <div className="raised-card bg-[#1C1C1C] border-y border-white/5 p-8 md:p-12 relative overflow-hidden">
                <div className="text-center mb-12">
                    <h3 className="text-3xl font-black text-white uppercase tracking-tight">The Protocol</h3>
                    <p className="text-gray-500 text-sm mt-2">How to operate within the Search Mafia</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
                    {CMS.syndicate.steps.map((step, idx) => (
                        <div key={idx} className="relative group">
                            <div className={`text-6xl font-black text-[#262626] absolute -top-4 -left-2 z-0 transition-colors ${
                                idx === 0 ? 'group-hover:text-[#D4AF37]/10' : 
                                idx === 1 ? 'group-hover:text-[#00AACC]/10' :
                                idx === 2 ? 'group-hover:text-green-500/10' : 'group-hover:text-white/10'
                            }`}>{step.id}</div>
                            <div className={`relative z-10 p-4 border-l-2 bg-gradient-to-r to-transparent ${
                                idx === 0 ? 'border-[#D4AF37] from-[#D4AF37]/5' : 
                                idx === 1 ? 'border-[#00AACC] from-[#00AACC]/5' :
                                idx === 2 ? 'border-green-500 from-green-500/5' : 'border-white from-white/5'
                            }`}>
                                <h4 className="text-white font-bold uppercase text-sm mb-2">{step.title}</h4>
                                <p className="text-xs text-gray-400 leading-relaxed">{step.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* 3. MISSION & TACTICAL ARMORY */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* The Mission */}
                <div className="p-8 bg-neutral-900/50 border border-neutral-800 rounded-xl">
                    <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-4">The Mission</h3>
                    <p className="text-gray-400 text-sm leading-relaxed mb-6">
                        We are looking for individuals interested in pushing online services to businesses in underserved areas. There are hard-working service providers serving the community that just don't care about devices. You are their bridge to the digital economy.
                    </p>
                    <div className="flex gap-2">
                        <span className="text-[10px] font-black uppercase tracking-widest bg-[#D4AF37]/10 text-[#D4AF37] px-3 py-1 rounded">Commission Based</span>
                        <span className="text-[10px] font-black uppercase tracking-widest bg-blue-500/10 text-blue-500 px-3 py-1 rounded">Remote Work</span>
                    </div>
                </div>

                {/* Tactical Armory */}
                <div className="p-8 bg-neutral-900/50 border border-neutral-800 rounded-xl">
                    <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-4">Tactical Armory</h3>
                    <p className="text-gray-400 text-sm leading-relaxed mb-6">
                        Use these public tools to demonstrate value to potential clients or protect your community.
                    </p>
                    <div className="space-y-3">
                        <button onClick={() => onNavigate('guide')} className="w-full text-left flex items-center justify-between p-3 rounded bg-black/40 border border-white/5 hover:border-purple-500/50 group transition-all">
                            <span className="text-xs font-bold text-gray-300 group-hover:text-purple-400">Victim's Defense Guide (StopNCII)</span>
                            <span className="text-purple-500 opacity-0 group-hover:opacity-100 transition-opacity">→</span>
                        </button>
                        <button onClick={() => onNavigate('hygiene')} className="w-full text-left flex items-center justify-between p-3 rounded bg-black/40 border border-white/5 hover:border-blue-500/50 group transition-all">
                            <span className="text-xs font-bold text-gray-300 group-hover:text-blue-400">Data Hygiene Workbook</span>
                            <span className="text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">→</span>
                        </button>
                        <button onClick={() => onNavigate('free-audit')} className="w-full text-left flex items-center justify-between p-3 rounded bg-black/40 border border-white/5 hover:border-[#00AACC]/50 group transition-all">
                            <span className="text-xs font-bold text-gray-300 group-hover:text-[#00AACC]">Free SEO Audit Tool</span>
                            <span className="text-[#00AACC] opacity-0 group-hover:opacity-100 transition-opacity">→</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* 4. ACADEMY & AFFILIATE */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Free Academy */}
                <div onClick={() => onNavigate('mafia/academy')} className="group cursor-pointer raised-card bg-[#1C1C1C] border-t-4 border-blue-500 p-10 hover:-translate-y-2 transition-all duration-300 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /></svg>
                    </div>
                    <div className="relative z-10">
                        <h3 className="text-3xl font-black text-white uppercase tracking-tight mb-2">Free Academy</h3>
                        <p className="text-sm text-gray-400 mb-6 font-medium">
                            Stop paying gurus. Access world-class certifications from Google, Meta, and Coursera for free. 
                        </p>
                        <span className="inline-flex items-center gap-2 bg-blue-500/10 text-blue-500 px-4 py-2 rounded text-[10px] font-black uppercase tracking-widest border border-blue-500/20 group-hover:bg-blue-500 group-hover:text-black transition-colors">
                            Start Learning <span>→</span>
                        </span>
                    </div>
                </div>

                {/* Affiliate Program */}
                <div onClick={() => onNavigate('mafia/membership')} className="group cursor-pointer raised-card bg-[#1C1C1C] border-t-4 border-[#D4AF37] p-10 hover:-translate-y-2 transition-all duration-300 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <div className="relative z-10">
                        <h3 className="text-3xl font-black text-white uppercase tracking-tight mb-2">Membership Application</h3>
                        <p className="text-sm text-gray-400 mb-6 font-medium">
                            Already scouted a lead? Submit your application to the syndicate.
                        </p>
                        <span className="inline-flex items-center gap-2 bg-[#D4AF37]/10 text-[#D4AF37] px-4 py-2 rounded text-[10px] font-black uppercase tracking-widest border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
                            Apply Now <span>→</span>
                        </span>
                    </div>
                </div>
            </div>

            {/* Freemium Tool Hint */}
            <div className="text-center pt-8 border-t border-white/10">
                <p className="text-gray-500 text-sm italic">
                    "This came about when I was busy chatting to a friend of mine in December, and he was in Coffee Bay. So it worked out nicely."
                </p>
            </div>
        </div>
    );
};
