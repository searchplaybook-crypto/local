
import React, { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface ProtocolStep {
  id: string;
  platform: string;
  task: string;
}

interface ProtocolCategory {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  steps: ProtocolStep[];
}

const PROTOCOLS: ProtocolCategory[] = [
  {
    id: 'global',
    title: 'Global Platforms',
    description: 'Big Tech Surveillance Defense',
    color: '#00AACC',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.012 6.012 0 011.912-2.706C6.512 5.73 6.974 6 7.5 6A1.5 1.5 0 019 7.5V8a2 2 0 004 0 2 2 0 011.523-1.943A5.977 5.977 0 0116 10c0 .34-.028.675-.083 1H15a2 2 0 00-2 2v2.197A5.973 5.973 0 0110 16v-2a2 2 0 00-2-2 2 2 0 01-2-2 2 2 0 00-1.668-1.973z" clipRule="evenodd" /></svg>,
    steps: [
      { id: 'g1', platform: 'Google', task: "Auto-Delete: Set 'Web & App Activity' to 3 months (My Activity)." },
      { id: 'g2', platform: 'Google', task: "Maps: Turn off 'Location History' (Timeline) or set auto-delete." },
      { id: 'g3', platform: 'Google', task: "Search: Use 'Results about you' tool to remove personal contact info." },
      { id: 'g4', platform: 'Google', task: "Security: Revoke access for unused Third-Party Apps." },
      
      { id: 'm1', platform: 'Meta', task: "Facebook: Clear 'Off-Facebook Activity' history & disconnect future activity." },
      { id: 'm2', platform: 'Meta', task: "Instagram: Set account to Private & turn off 'Activity Status'." },
      { id: 'm3', platform: 'Meta', task: "WhatsApp: Enable 2FA PIN (Settings > Account > Two-Step)." },
      { id: 'm4', platform: 'Meta', task: "Ads: Review 'Ad Preferences' and hide all profile data visibility." },

      { id: 't1', platform: 'TikTok', task: "Privacy: Toggle 'Private Account' to ON." },
      { id: 't2', platform: 'TikTok', task: "Sync: Turn off 'Suggest your account to others'." },
      { id: 't3', platform: 'TikTok', task: "Downloads: Turn off 'Allow your videos to be downloaded'." },
      { id: 't4', platform: 'TikTok', task: "Ads: Disable 'Personalized Ads' in Safety settings." },

      { id: 'l1', platform: 'LinkedIn', task: "Visibility: Set Profile Viewing options to 'Private Mode'." },
      { id: 'l2', platform: 'LinkedIn', task: "Data: Remove synced contacts and calendar." },
      { id: 'l3', platform: 'Microsoft', task: "Privacy Dashboard: Clear Search & Browsing History." },
      { id: 'l4', platform: 'Microsoft', task: "Windows: Turn off 'Advertising ID' in OS settings." },
    ]
  },
  {
    id: 'local',
    title: 'SA Local Context',
    description: 'Gov, Media & Retail',
    color: '#D4AF37',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>,
    steps: [
      { id: 'loc1', platform: 'News Sites', task: "Tracking: Use Brave Browser for News24/IOL to block ad-trackers." },
      { id: 'loc2', platform: 'News Sites', task: "Cookies: Select 'Reject All' on POPIA consent popups." },
      { id: 'loc3', platform: 'Gov Portals', task: "SARS/eHomeAffairs: Use unique passwords (Never reuse social credentials)." },
      { id: 'loc4', platform: 'Gov Portals', task: "Session: Log out immediately. Clear cache after using shared PCs." },
      { id: 'loc5', platform: 'Malls', task: "Wi-Fi: 'Forget' Mall networks (e.g., Sandton/Mall of Africa) after use." },
      { id: 'loc6', platform: 'Malls', task: "Bluetooth: Turn OFF when shopping to stop beacon location tracking." },
      { id: 'loc7', platform: 'Loyalty Apps', task: "Checkers/PnP: Deny Microphone & Camera permissions in settings." },
      { id: 'loc8', platform: 'ISP/Fibre', task: "Home: Change default Admin Password on your Vuma/Openserve router." },
    ]
  },
  {
    id: 'monthly',
    title: 'Monthly Maintenance',
    description: 'Routine Checkup',
    color: '#10B981',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>,
    steps: [
      { id: 'mon1', platform: 'Finance', task: "Bank: Audit statement for unknown debit orders (R99 scams)." },
      { id: 'mon2', platform: 'Breaches', task: "Intel: Check email on HaveIBeenPwned.com." },
      { id: 'mon3', platform: 'Backups', task: "Data: Sync Photos/Docs to encrypted cloud or offline drive." },
      { id: 'mon4', platform: 'Updates', task: "Security: Install latest iOS/Android OS patches." },
    ]
  }
];

export const DataHygiene: React.FC = () => {
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const [activeCategory, setActiveCategory] = useState<string>('global');

  const toggleTask = (id: string) => {
    const newSet = new Set(completed);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setCompleted(newSet);
  };

  const currentCategory = PROTOCOLS.find(p => p.id === activeCategory) || PROTOCOLS[0];

  // Calculate Metrics
  const totalTasks = PROTOCOLS.reduce((acc, curr) => acc + curr.steps.length, 0);
  const completedCount = completed.size;
  const progress = Math.round((completedCount / totalTasks) * 100);

  const chartData = [
    { name: 'Completed', value: completedCount, color: '#00AACC' },
    { name: 'Remaining', value: totalTasks - completedCount, color: '#333' }
  ];

  return (
    <section id="data-hygiene" className="mb-16 raised-card rounded-2xl p-6 md:p-12 bg-[#1C1C1C] border border-neutral-800 shadow-2xl relative overflow-hidden">
        
        {/* Header & Metrics */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-8 border-b border-white/5 pb-8">
            <div className="max-w-xl">
                <span className="text-[#00AACC] font-black tracking-[0.2em] uppercase text-[10px] mb-2 block">Comprehensive Workbook</span>
                <h2 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tight">Data Hygiene Protocol</h2>
                <p className="text-gray-400 text-sm mt-3 leading-relaxed">
                    Digital exhaust is dangerous. Use this interactive workbook to systematically scrub your footprint across Global Platforms, Local SA Environments, and Monthly Routines.
                </p>
            </div>
            
            {/* Donut Chart */}
            <div className="flex items-center gap-6 bg-black/20 p-4 rounded-xl border border-white/5">
                <div className="text-right">
                    <span className="block text-3xl font-black text-white">{progress}%</span>
                    <span className="text-[9px] uppercase tracking-widest text-gray-500 font-bold">Protocol Status</span>
                </div>
                <div className="w-20 h-20 relative">
                     <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={chartData}
                                cx="50%"
                                cy="50%"
                                innerRadius={28}
                                outerRadius={40}
                                startAngle={90}
                                endAngle={-270}
                                dataKey="value"
                                stroke="none"
                            >
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                        </PieChart>
                     </ResponsiveContainer>
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        {progress === 100 && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                        )}
                     </div>
                </div>
            </div>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
            {PROTOCOLS.map((cat) => (
                <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`
                        flex items-center gap-2 px-6 py-4 rounded-lg transition-all duration-300 border
                        ${activeCategory === cat.id 
                            ? 'bg-neutral-800 text-white border-white/20 shadow-lg scale-105' 
                            : 'bg-transparent text-gray-500 border-transparent hover:bg-neutral-900 hover:text-gray-300'}
                    `}
                >
                    <div className={`${activeCategory === cat.id ? 'text-white' : 'text-gray-600'}`}>{cat.icon}</div>
                    <div className="text-left">
                        <span className="block text-xs font-black uppercase tracking-widest">{cat.title}</span>
                        <span className="block text-[9px] font-medium opacity-60">{cat.description}</span>
                    </div>
                </button>
            ))}
        </div>

        {/* Task List */}
        <div className="grid grid-cols-1 gap-3 animate-fade-in key={activeCategory}">
            {currentCategory.steps.map((step) => {
                const isCompleted = completed.has(step.id);
                return (
                    <div 
                        key={step.id}
                        onClick={() => toggleTask(step.id)}
                        className={`
                            p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all duration-200 group
                            ${isCompleted
                                ? `bg-[${currentCategory.color}]/10 border-[${currentCategory.color}]/30` 
                                : 'bg-[#262626] border-white/5 hover:border-white/10 hover:translate-x-1'}
                        `}
                        style={{
                            backgroundColor: isCompleted ? `${currentCategory.color}15` : undefined,
                            borderColor: isCompleted ? `${currentCategory.color}40` : undefined
                        }}
                    >
                        <div className="flex items-center gap-4 w-full">
                            <div className={`
                                w-6 h-6 rounded-md flex-shrink-0 flex items-center justify-center border transition-colors
                                ${isCompleted ? 'bg-transparent' : 'bg-transparent border-gray-600'}
                            `}
                            style={{ 
                                borderColor: isCompleted ? currentCategory.color : undefined,
                                backgroundColor: isCompleted ? currentCategory.color : undefined
                            }}
                            >
                                {isCompleted && (
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-black" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                    </svg>
                                )}
                            </div>
                            <div className="flex flex-col md:flex-row md:items-center gap-1 md:gap-4 w-full">
                                <span className={`text-[10px] font-black uppercase tracking-widest w-24 shrink-0 transition-colors ${isCompleted ? 'text-white' : 'text-gray-500'}`}>
                                    {step.platform}
                                </span>
                                <span className={`text-sm font-medium transition-colors ${isCompleted ? 'text-white' : 'text-gray-400 group-hover:text-gray-200'}`}>
                                    {step.task}
                                </span>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
        
        <div className="mt-8 p-4 bg-black/20 rounded border border-white/5 text-center flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">
                Progress saves locally. Perform the "Monthly Maintenance" steps every 30 days.
            </p>
        </div>
    </section>
  );
};
