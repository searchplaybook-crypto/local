import React from 'react';

export const ImmediateAction: React.FC = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact-form');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="immediate-action" className="mb-16">
      <div className="text-center mb-10">
        <span className="text-yellow-500 font-bold tracking-[0.2em] uppercase text-[10px] mb-2 block">Phase 1</span>
        <h2 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tight">Stop The Damage</h2>
        <div className="h-1 w-20 bg-cyan-500 mx-auto mt-4 mb-3 rounded-full opacity-50"></div>
        <p className="text-gray-400 max-w-2xl mx-auto text-sm font-medium">
          The first 24 hours are the most important. Do not fight back yet. Secure yourself first.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {/* Card 1: Block/Contain */}
        <div className="raised-card p-6 rounded-xl hover:-translate-y-1 active:scale-[0.98] transition-all duration-300 relative overflow-hidden group cursor-default">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-cyan-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
             </svg>
          </div>
          <div className="text-4xl text-cyan-500/20 mb-4 font-black select-none">01</div>
          <h3 className="text-lg font-black text-white uppercase tracking-tight mb-3">Block Them</h3>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2 text-cyan-400">Why:</p>
          <p className="text-sm text-gray-200 leading-relaxed font-medium">
            Talking to them gives them power. If you have to talk (like for kids), use only strict, short messages.
          </p>
        </div>

        {/* Card 2: Zero Negotiation */}
        <div className="raised-card p-6 rounded-xl hover:-translate-y-1 active:scale-[0.98] transition-all duration-300 relative overflow-hidden group cursor-default">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
             </svg>
          </div>
          <div className="text-4xl text-yellow-500/20 mb-4 font-black select-none">02</div>
          <h3 className="text-lg font-black text-white uppercase tracking-tight mb-3">Don't Negotiate</h3>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2 text-yellow-500">Why:</p>
          <p className="text-sm text-gray-200 leading-relaxed font-medium">
            Paying or begging does not work. It just shows them they have control. Silence is your best defense.
          </p>
        </div>

        {/* Card 3: Secure Proof */}
        <div className="raised-card p-6 rounded-xl hover:-translate-y-1 active:scale-[0.98] transition-all duration-300 relative overflow-hidden group cursor-default">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
             </svg>
          </div>
          <div className="text-4xl text-blue-500/20 mb-4 font-black select-none">03</div>
          <h3 className="text-lg font-black text-white uppercase tracking-tight mb-3">Save Proof</h3>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2 text-blue-400">Why:</p>
          <p className="text-sm text-gray-200 leading-relaxed font-medium">
            You need evidence for the police. Screenshot numbers, website links, and times <em>before</em> blocking. Don't delete chats; archive them.
          </p>
        </div>

        {/* Card 4: Council */}
        <div className="raised-card p-6 rounded-xl hover:-translate-y-1 active:scale-[0.98] transition-all duration-300 relative overflow-hidden group cursor-default">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
             </svg>
          </div>
          <div className="text-4xl text-purple-500/20 mb-4 font-black select-none">04</div>
          <h3 className="text-lg font-black text-white uppercase tracking-tight mb-3">Get Help</h3>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2 text-purple-400">Why:</p>
          <p className="text-sm text-gray-200 leading-relaxed font-medium">
            Being alone makes you weak. To stop this, you need professional help. Call a support line or a lawyer immediately.
          </p>
        </div>
      </div>

      <div className="flex justify-center no-print">
        <button 
          onClick={scrollToContact}
          className="inline-flex items-center gap-4 bg-cyan-600 hover:bg-cyan-500 text-white font-black uppercase text-xl py-6 px-12 rounded-full shadow-[0_0_20px_rgba(0,170,204,0.5)] hover:shadow-[0_0_35px_rgba(0,170,204,0.8)] transition-all transform hover:scale-[1.03] active:scale-95 border-t border-cyan-400/50 group"
        >
          <span>Start Takedown Process</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </button>
      </div>
    </section>
  );
};