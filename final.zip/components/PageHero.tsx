import React from 'react';

interface PageHeroProps {
  tagline: string;
  title?: string;
  image?: string;
  cta?: string;
  onCtaClick?: () => void;
}

export const PageHero: React.FC<PageHeroProps> = ({ tagline, title, image, cta, onCtaClick }) => {
  // Using a fallback default image if none provided
  const bgImage = image ? `/assets/images/${image}` : 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1920';

  return (
    <div className="relative w-full rounded-3xl overflow-hidden raised-card border-none bg-neutral-900 group h-[400px] mb-12">
      <div className="absolute inset-0 w-full h-full bg-black">
        <img 
            src={bgImage}
            alt={tagline}
            className="w-full h-full object-cover opacity-50 group-hover:opacity-60 transition-opacity duration-700"
            onError={(e) => {
                // Fallback for demo purposes if assets aren't strictly local
                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1920"; 
            }}
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/40 to-transparent"></div>
      
      <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16 max-w-4xl relative z-10">
        <h1 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter leading-none mb-4 drop-shadow-xl">
          {title || "WMC Playbook"}
        </h1>
        <p className="text-xl md:text-2xl text-[#D4AF37] font-bold uppercase tracking-widest mb-8 border-l-4 border-[#00AACC] pl-4">
          {tagline}
        </p>
        
        {cta && (
          <button 
            onClick={onCtaClick}
            className="w-fit bg-[#00AACC] hover:bg-white hover:text-black text-white font-black uppercase text-sm py-4 px-8 rounded-lg transition-all shadow-lg"
          >
            {cta}
          </button>
        )}
      </div>
    </div>
  );
};