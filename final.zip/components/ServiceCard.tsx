import React from 'react';

interface ServiceCardProps {
  title: string;
  price: string;
  frequency: string;
  description?: string;
  highlight?: boolean;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ title, price, frequency, description, highlight }) => {
  return (
    <div className={`p-6 rounded-xl border transition-all duration-300 flex flex-col justify-between h-full group halo-card-gold hover:scale-[1.02] ${
        highlight 
        ? 'bg-[#D4AF37]/5 border-[#D4AF37]/30' 
        : 'bg-[#1C1C1C] border-white/5'
    }`}>
      <div>
        <h4 className={`text-lg font-black uppercase tracking-tight mb-2 ${highlight ? 'text-[#D4AF37]' : 'text-white group-hover:text-[#D4AF37] transition-colors'}`}>{title}</h4>
        {description && <p className="text-xs text-gray-400 mb-4 font-medium leading-relaxed">{description}</p>}
      </div>
      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="flex items-baseline gap-1">
          <span className={`text-2xl font-black ${highlight ? 'text-white' : 'text-gray-200 group-hover:text-white transition-colors'}`}>{price}</span>
          <span className="text-[10px] text-gray-500 font-bold uppercase">{frequency}</span>
        </div>
      </div>
    </div>
  );
};