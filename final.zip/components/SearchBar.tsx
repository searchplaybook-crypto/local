import React, { useState, useEffect, useRef } from 'react';

interface SearchResult {
  title: string;
  category: string;
  route: string;
  id?: string; // For scrolling to specific sections
}

interface SearchBarProps {
  onNavigate: (page: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const SEARCH_INDEX: SearchResult[] = [
  { title: 'Stop Digital Abuse (Guide)', category: 'Playbook', route: 'guide' },
  { title: 'Secure Your Data (Workbook)', category: 'Playbook', route: 'hygiene' },
  { title: 'Join Search Mafia (Team)', category: 'Earn', route: 'learn-earn' },
  { title: 'Immediate Shutdown Protocol', category: 'Guide', route: 'guide', id: 'immediate-action' },
  { title: 'Website Optimization', category: 'Solutions', route: 'solutions' },
  { title: 'Google Removal / Takedown', category: 'Solutions', route: 'solutions' },
  { title: 'Legal Strategy Dashboard', category: 'Guide', route: 'guide', id: 'legal-strategy' },
  { title: 'Contact / Secure Line', category: 'Contact', route: 'home', id: 'contact-form' },
  { title: 'Case Studies (Success)', category: 'Proof', route: 'success' },
  { title: 'Hashing Tool', category: 'Tools', route: 'guide', id: 'hashing-explained' },
  { title: 'Service Level Agreement', category: 'Legal', route: 'sla' },
];

export const SearchBar: React.FC<SearchBarProps> = ({ onNavigate, isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const lowerQuery = query.toLowerCase();
    const filtered = SEARCH_INDEX.filter(item => 
      item.title.toLowerCase().includes(lowerQuery) || 
      item.category.toLowerCase().includes(lowerQuery)
    );
    setResults(filtered);
  }, [query]);

  const handleSelect = (result: SearchResult) => {
    onNavigate(result.route);
    if (result.id) {
      setTimeout(() => {
        const el = document.getElementById(result.id!);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 300); // Small delay to allow page switch
    }
    onClose();
    setQuery('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[3000] bg-black/90 backdrop-blur-sm flex items-start justify-center pt-24 px-4 animate-fade-in">
      <div className="w-full max-w-2xl bg-[#1C1C1C] border border-neutral-700 rounded-2xl shadow-2xl overflow-hidden relative">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="p-6 border-b border-white/5">
          <div className="flex items-center gap-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00AACC]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input 
              ref={inputRef}
              type="text" 
              className="w-full bg-transparent border-none outline-none text-white text-xl placeholder-gray-600 font-bold uppercase tracking-wide"
              placeholder="SEARCH PROTOCOLS..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="max-h-[60vh] overflow-y-auto">
          {results.length > 0 ? (
            <div className="divide-y divide-white/5">
              {results.map((result, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelect(result)}
                  className="w-full text-left px-6 py-4 hover:bg-white/5 transition-colors flex items-center justify-between group"
                >
                  <span className="text-gray-200 font-bold group-hover:text-[#00AACC] transition-colors">{result.title}</span>
                  <span className="text-[10px] uppercase tracking-widest text-gray-500 border border-white/10 px-2 py-1 rounded group-hover:border-[#00AACC]/30 group-hover:text-[#00AACC]">
                    {result.category}
                  </span>
                </button>
              ))}
            </div>
          ) : query ? (
            <div className="p-8 text-center text-gray-500">
              <p className="text-sm">No protocols found matching coordinates.</p>
            </div>
          ) : (
            <div className="p-8">
               <p className="text-[10px] font-black uppercase tracking-widest text-gray-600 mb-4">Quick Access</p>
               <div className="flex flex-wrap gap-2">
                  <button onClick={() => handleSelect(SEARCH_INDEX[0])} className="px-3 py-1 bg-white/5 hover:bg-[#00AACC]/20 hover:text-[#00AACC] rounded text-xs text-gray-400 transition-colors">Stop Abuse</button>
                  <button onClick={() => handleSelect(SEARCH_INDEX[2])} className="px-3 py-1 bg-white/5 hover:bg-[#D4AF37]/20 hover:text-[#D4AF37] rounded text-xs text-gray-400 transition-colors">Join Team</button>
                  <button onClick={() => handleSelect(SEARCH_INDEX[7])} className="px-3 py-1 bg-white/5 hover:bg-green-500/20 hover:text-green-500 rounded text-xs text-gray-400 transition-colors">Contact</button>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};