import React from 'react';
import { JusticeStats } from './JusticeStats';

export const WhyThisMatters: React.FC = () => {
  return (
    <section id="why-this-matters" className="mb-20 bg-[#333] border border-neutral-700 border-t-[#666] border-b-black/80 rounded-2xl shadow-2xl p-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-yellow-500 to-cyan-500"></div>
        
        <div className="text-center mb-10 max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-6 uppercase tracking-tight drop-shadow-md">Why This Matters</h2>
            
            <div className="space-y-4 text-gray-200 text-sm md:text-base leading-relaxed text-justify sm:text-center mb-10 font-medium">
                <p>
                    Online abuse is real abuse. It invades your life and hurts your mind. Victims often feel paralyzing <strong>fear</strong> and feel <strong>alone</strong>. It makes you feel like you are worth less. The abuse makes you feel like someone is always watching you, even when you are offline.
                </p>
                <p>
                    People use lies on the internet to destroy jobs and reputations. The hardest part is <strong>gathering proof</strong> because digital things can disappear fast. Messages and posts can be deleted in seconds. You have to race against time to save the proof you need for the police.
                </p>
            </div>

            {/* Legal Stakes - Integrated with Raised Button Aesthetic */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-stretch mb-8">
                <div className="flex-1 bg-[#404040] border border-neutral-600 border-t-[#777] border-b-black/80 rounded-xl p-6 shadow-lg hover:-translate-y-0.5 transition-transform">
                    <span className="block text-xl font-bold text-yellow-500 mb-2 drop-shadow-sm uppercase tracking-wide">Cybercrimes Act</span>
                    <span className="text-sm text-gray-300 block leading-snug">
                    <strong className="text-white">Section 17:</strong> Sharing intimate photos without permission is a serious crime.
                    </span>
                </div>
                <div className="flex-1 bg-[#404040] border border-neutral-600 border-t-[#777] border-b-black/80 rounded-xl p-6 shadow-lg hover:-translate-y-0.5 transition-transform flex flex-col justify-center">
                    <span className="block text-4xl font-black text-cyan-400 mb-1 drop-shadow-sm">5 Years</span>
                    <span className="text-xs font-bold text-gray-300 uppercase tracking-widest">Max Prison Time</span>
                </div>
            </div>
        </div>

        <JusticeStats />
    </section>
  );
};