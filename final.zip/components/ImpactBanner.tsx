
import React, { useState, useEffect } from 'react';
import { CMS } from '../constants';

interface ImpactBannerProps {
  onNavigate?: (page: string) => void;
}

export const ImpactBanner: React.FC<ImpactBannerProps> = ({ onNavigate }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const SLIDES = CMS.heroSlides;

  useEffect(() => {
    if (!isAutoPlaying) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 6000); 
    return () => clearInterval(timer);
  }, [isAutoPlaying, SLIDES.length]);

  const handleCta = (target: string) => {
    onNavigate?.(target);
  };

  const slide = SLIDES[currentSlide];

  return (
    <div 
      className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 mb-12 no-print"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      <div className="relative h-[450px] md:h-[550px] rounded-3xl overflow-hidden raised-card border-none bg-neutral-900 group transition-all duration-700">
        
        {/* Background Images */}
        <div className="absolute inset-0 w-full h-full bg-black">
            {SLIDES.map((s, idx) => (
                <div 
                    key={s.id}
                    className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ${currentSlide === idx ? 'opacity-100' : 'opacity-0'}`}
                >
                    <img 
                        src={s.image}
                        alt={s.title}
                        className="w-full h-full object-cover"
                        style={{ filter: 'contrast(1.2) brightness(0.4)' }}
                        loading={idx === 0 ? "eager" : "lazy"}
                    />
                </div>
            ))}
        </div>
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/60 to-transparent"></div>
        
        {/* Content Container */}
        <div className="absolute inset-0 flex flex-col justify-center p-8 md:p-16 max-w-3xl transition-all duration-500 relative z-10">
          
          {/* Badge */}
          <div key={`badge-${currentSlide}`} className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-neutral-950/80 border border-white/10 rounded-full mb-6 shadow-lg backdrop-blur-sm w-fit animate-fade-in">
            <span className={`w-1.5 h-1.5 rounded-full animate-pulse bg-gradient-to-r ${slide.gradient}`}></span>
            <span className="text-[10px] font-black uppercase tracking-[0.1em] text-gray-300">{slide.badge}</span>
          </div>
          
          {/* Main Heading */}
          <h2 key={`title-${currentSlide}`} className="text-4xl md:text-7xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-6 drop-shadow-2xl min-h-[120px] md:min-h-[140px] animate-fade-in">
            {slide.title} <br/>
            <span className={`text-transparent bg-clip-text bg-gradient-to-r ${slide.gradient}`}>
              {slide.titleHighlight}
            </span>
          </h2>
          
          {/* Subtext */}
          <p key={`desc-${currentSlide}`} className="text-sm md:text-lg text-gray-300 font-medium leading-relaxed drop-shadow-lg mb-8 max-w-xl min-h-[80px] animate-fade-in border-l-4 border-white/10 pl-6">
            {slide.desc}
          </p>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => handleCta(slide.target)}
              className={`flex items-center justify-center gap-3 text-black font-black uppercase text-xs md:text-sm py-4 px-8 rounded-lg shadow-lg transition-all transform hover:-translate-y-1 bg-gradient-to-r ${slide.gradient} hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]`}
            >
              <span>{slide.cta}</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </button>
            
            {/* Secondary Link */}
            <button 
               onClick={() => onNavigate?.('solutions')}
               className="flex items-center justify-center gap-2 text-white border border-white/10 hover:bg-white/5 font-black uppercase text-xs md:text-sm py-4 px-8 rounded-lg transition-all"
            >
               View Ecosystem
            </button>
          </div>
        </div>

        {/* Indicators */}
        <div className="absolute bottom-8 left-8 md:left-16 flex gap-3 z-10">
            {SLIDES.map((s, idx) => (
                <button
                    key={s.id}
                    onClick={() => setCurrentSlide(idx)}
                    className={`h-1.5 rounded-full transition-all duration-300 ${currentSlide === idx ? `w-8 bg-gradient-to-r ${s.gradient}` : 'w-2 bg-gray-700 hover:bg-gray-500'}`}
                    aria-label={`Go to slide ${idx + 1}`}
                />
            ))}
        </div>
      </div>
    </div>
  );
};
