import React from 'react';

interface PricingBlockProps {
  title: string;
  price: string;
  frequency: string;
  tier: string;
  description: string;
  highlight?: boolean;
}

export const PricingBlock: React.FC<PricingBlockProps> = ({ title, price, frequency, tier, description, highlight }) => {
  return (
    <div className={`relative p-8 rounded-2xl border flex flex-col h-full transition-all duration-300 group hover:-translate-y-2 ${highlight ? 'bg-[#00AACC]/10 border-[#00AACC] shadow-[0_0_30px_rgba(0,170,204,0.15)]' : 'bg-[#1C1C1C] border-white/10 hover:border-white/30'}`}>
      {highlight && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-[#00AACC] text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full">
          Set & Forget Starter
        </div>
      )}
      
      <div className="mb-6">
        <span className={`text-[10px] font-black uppercase tracking-widest mb-2 block ${highlight ? 'text-[#00AACC]' : 'text-gray-500'}`}>{tier}</span>
        <h3 className="text-2xl font-black text-white uppercase tracking-tight">{title}</h3>
      </div>
      
      <div className="mb-6">
        <p className="text-sm text-gray-400 leading-relaxed font-medium min-h-[40px]">{description}</p>
      </div>
      
      <div className="mt-auto">
        <div className="flex items-baseline gap-1 mb-6">
          <span className={`text-4xl font-black ${highlight ? 'text-white' : 'text-gray-200'}`}>{price}</span>
          <span className="text-xs text-gray-500 font-bold uppercase">{frequency}</span>
        </div>
        
        <button className={`w-full py-4 rounded-lg font-black uppercase text-xs tracking-widest transition-all ${highlight ? 'bg-[#00AACC] text-white hover:bg-white hover:text-black' : 'bg-white/5 text-gray-300 hover:bg-white hover:text-black'}`}>
          Select Tier
        </button>
      </div>
    </div>
  );
};