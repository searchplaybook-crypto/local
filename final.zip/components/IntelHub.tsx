
import React from 'react';

interface IntelHubProps {
    onNavigate: (page: string) => void;
}

export const IntelHub: React.FC<IntelHubProps> = ({ onNavigate }) => {
    return (
        <div className="animate-fade-in py-12 space-y-12">
            
            {/* HERO SECTION */}
            <div className="relative w-full rounded-3xl overflow-hidden raised-card border-none bg-neutral-900 group h-[400px] mb-12">
                {/* Background Image */}
                <div className="absolute inset-0 w-full h-full">
                    <img 
                        src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=1920"
                        alt="Intel Hub Tactical Map"
                        className="w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-opacity duration-700"
                    />
                </div>
                
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/60 to-transparent"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-[#111]/90 via-transparent to-transparent"></div>

                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16 max-w-4xl relative z-10">
                    <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-blue-900/30 border border-blue-500/30 rounded-full mb-6 backdrop-blur-sm w-fit">
                        <span className="w-1.5 h-1.5 rounded-full animate-pulse bg-[#00AACC]"></span>
                        <span className="text-[10px] font-black uppercase tracking-[0.1em] text-blue-200">Operational Resources</span>
                    </div>
                    <h2 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-6">
                        Intel <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00AACC] to-cyan-100">Hub</span>
                    </h2>
                    <p className="text-gray-300 text-lg md:text-xl font-medium leading-relaxed max-w-2xl border-l-4 border-[#00AACC] pl-6">
                        Central command for digital sovereignty. Select a sector below to access tactical protocols, legal templates, and defensive tools.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                
                {/* 1. Tactical Tools (Main Sub-Page) */}
                <div onClick={() => onNavigate('intel/tactical')} className="group cursor-pointer raised-card bg-[#1C1C1C] border-t-4 border-[#D4AF37] p-8 hover:-translate-y-2 transition-transform duration-300">
                    <div className="h-12 w-12 bg-[#D4AF37]/10 rounded-lg flex items-center justify-center text-[#D4AF37] mb-6 group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                    </div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-2">Tactical Tools</h3>
                    <p className="text-sm text-gray-400 leading-relaxed mb-6">Active utilities including the Job Market Gauge and Secure Hasher.</p>
                    <span className="text-[#D4AF37] text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all">Open Toolbox <span>→</span></span>
                </div>

                {/* 2. Cyber Safety Guides (New Sub-Page) */}
                <div onClick={() => onNavigate('intel/safety-guides')} className="group cursor-pointer raised-card bg-[#1C1C1C] border-t-4 border-[#00AACC] p-8 hover:-translate-y-2 transition-transform duration-300">
                    <div className="h-12 w-12 bg-[#00AACC]/10 rounded-lg flex items-center justify-center text-[#00AACC] mb-6 group-hover:bg-[#00AACC] group-hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                    </div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-2">Cyber Safety Guides</h3>
                    <p className="text-sm text-gray-400 leading-relaxed mb-6">Defensive protocols. StopNCII, Data Hygiene, and Scam Defense strategies.</p>
                    <span className="text-[#00AACC] text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all">Access Library <span>→</span></span>
                </div>

                {/* 3. Takedown Notices (New Sub-Page) */}
                <div onClick={() => onNavigate('intel/takedown-notices')} className="group cursor-pointer raised-card bg-[#1C1C1C] border-t-4 border-purple-500 p-8 hover:-translate-y-2 transition-transform duration-300">
                    <div className="h-12 w-12 bg-purple-500/10 rounded-lg flex items-center justify-center text-purple-500 mb-6 group-hover:bg-purple-500 group-hover:text-black transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                    </div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-2">Takedown Notices</h3>
                    <p className="text-sm text-gray-400 leading-relaxed mb-6">Legal templates and formal request structures for content removal.</p>
                    <span className="text-purple-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all">View Templates <span>→</span></span>
                </div>

            </div>
        </div>
    );
};
