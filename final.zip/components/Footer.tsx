import React from 'react';
import { SocialShare } from './SocialShare';
import { CMS } from '../constants';

interface FooterProps {
  onNavigate?: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNav = (page: string) => {
    if (onNavigate) {
        onNavigate(page);
    } else {
        window.location.hash = page;
    }
  };

  return (
    <footer className="py-20 mt-auto border-t border-white/5 bg-black/40 text-center px-6 no-print w-full relative z-50">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
            {/* Branding - Shield Shape */}
            <div className="mb-8 group cursor-default">
               <div className="w-12 h-14 bg-[#00AACC] flex flex-col items-center justify-center pt-1 border-b-4 border-black/20 shadow-lg mx-auto mb-5 group-hover:scale-110 group-hover:shadow-[0_0_25px_rgba(0,170,204,0.6)] transition-all duration-300 rounded-t-lg rounded-b-[3rem] relative z-10">
                 <span className="text-black text-[9px] font-black leading-none text-center tracking-tighter">{CMS.identity.short}</span>
                 <span className="text-black text-[9px] font-black leading-none text-center tracking-tighter">ZA</span>
               </div>
               <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 group-hover:text-[#00AACC] group-hover:drop-shadow-[0_0_5px_rgba(0,170,204,0.5)] transition-all duration-300">
                  {CMS.identity.tagline}
               </p>
               <p className="text-[9px] text-gray-600 mt-2 font-bold tracking-widest">© {currentYear} {CMS.identity.full}</p>
            </div>

            {/* Contact Details */}
            <div className="mb-10 flex flex-col md:flex-row gap-6 md:gap-12 items-center justify-center border-t border-b border-white/5 py-8 w-full max-w-2xl">
                 <div className="flex flex-col items-center group">
                    <div className="mb-2 p-2 rounded-full bg-neutral-900 border border-neutral-800 text-gray-500 group-hover:text-[#00AACC] group-hover:border-[#00AACC]/50 transition-all">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    </div>
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-1 group-hover:text-white transition-colors">Enquiries</p>
                    <a href={`mailto:${CMS.identity.contact}`} className="text-sm font-medium text-gray-300 group-hover:text-[#00AACC] transition-colors hover:drop-shadow-[0_0_8px_rgba(0,170,204,0.4)]">{CMS.identity.contact}</a>
                 </div>
                 
                 <div className="hidden md:block w-px h-12 bg-white/10"></div>
                 
                 <div className="flex flex-col items-center group">
                    <div className="mb-2 p-2 rounded-full bg-neutral-900 border border-neutral-800 text-gray-500 group-hover:text-[#D4AF37] group-hover:border-[#D4AF37]/50 transition-all">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    </div>
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-1 group-hover:text-white transition-colors">Location</p>
                    <span className="text-sm font-medium text-gray-300 group-hover:text-[#D4AF37] transition-colors hover:drop-shadow-[0_0_8px_rgba(212,175,55,0.4)]">{CMS.identity.location}</span>
                 </div>
            </div>

            {/* Social Share Integration */}
            <div className="mb-8 w-full max-w-xl mx-auto">
              <SocialShare />
            </div>
            
            {/* Footer Navigation */}
            <div className="flex flex-wrap justify-center items-center gap-y-4 gap-x-8">
                <button 
                  onClick={() => handleNav('legal/terms')}
                  className="group flex items-center gap-3 text-[10px] font-bold text-gray-600 uppercase tracking-widest hover:text-[#D4AF37] transition-all duration-200"
                >
                   <div className="p-1.5 rounded-md bg-neutral-900 border border-neutral-800 text-[#D4AF37] group-hover:border-[#D4AF37]/50 group-hover:shadow-[0_0_15px_rgba(212,175,55,0.5)] transition-all">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                   </div>
                  <span className="group-hover:drop-shadow-[0_0_5px_rgba(212,175,55,0.5)]">Terms & Disclaimer</span>
                </button>

                <div className="hidden md:block w-px h-3 bg-white/10"></div>

                <button 
                  onClick={() => handleNav('legal/privacy')}
                  className="group flex items-center gap-3 text-[10px] font-bold text-gray-600 uppercase tracking-widest hover:text-[#00AACC] transition-all duration-200"
                >
                   <div className="p-1.5 rounded-md bg-neutral-900 border border-neutral-800 text-[#00AACC] group-hover:border-[#00AACC]/50 group-hover:shadow-[0_0_15px_rgba(0,170,204,0.5)] transition-all">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                   </div>
                  <span className="group-hover:drop-shadow-[0_0_5px_rgba(0,170,204,0.5)]">Privacy Policy</span>
                </button>
                
                <div className="hidden md:block w-px h-3 bg-white/10"></div>

                <button 
                  onClick={scrollToTop} 
                  className="group flex items-center gap-2 text-[10px] font-bold text-gray-500 hover:text-white uppercase tracking-widest transition-all duration-300 px-4 py-2 rounded-full border border-transparent hover:border-white/10 hover:bg-white/5 hover:shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                  aria-label="Scroll to top of page"
                >
                  Back To Top
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 group-hover:-translate-y-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  </svg>
                </button>
            </div>
        </div>
    </footer>
  );
};