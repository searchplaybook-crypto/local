import React from 'react';
import { PageHero } from './PageHero';
import { CMS } from '../constants';
import { SEO } from './SEO';

export const Academy: React.FC = () => {
  const content = CMS.pages.academy;

  return (
    <div className="animate-fade-in pb-12">
      <SEO title={content.title} description={content.description} />
      <PageHero 
        title={content.title}
        tagline={content.tagline} 
        image={content.heroImage}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="raised-card p-8 bg-[#1C1C1C]">
          <h3 className="text-xl font-black text-white uppercase mb-4">Learning Modules</h3>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li className="flex gap-2"><span>•</span> SEO Fundamentals</li>
            <li className="flex gap-2"><span>•</span> Privacy Defense</li>
            <li className="flex gap-2"><span>•</span> Paid Advertising</li>
          </ul>
        </div>
        <div className="raised-card p-8 bg-[#1C1C1C]">
          <h3 className="text-xl font-black text-white uppercase mb-4">Tutorials & Guides</h3>
          <p className="text-gray-400 text-sm mb-4">Step-by-step walkthroughs for digital tools.</p>
          <button className="text-[#00AACC] text-xs font-black uppercase tracking-widest">Access Library &rarr;</button>
        </div>
        <div className="raised-card p-8 bg-[#1C1C1C]">
          <h3 className="text-xl font-black text-white uppercase mb-4">Community</h3>
          <p className="text-gray-400 text-sm mb-4">Shared learning hub and resources.</p>
          <button className="text-[#D4AF37] text-xs font-black uppercase tracking-widest">Join Hub &rarr;</button>
        </div>
      </div>
    </div>
  );
};