import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Sector } from 'recharts';
import { EVIDENCE_DATA } from '../constants';

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;

  return (
    <g>
      {/* Outer Glow Ring */}
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={outerRadius + 2}
        outerRadius={outerRadius + 10}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        fillOpacity={0.3}
      />
      {/* Main Active Sector - Brighter & Larger */}
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius - 2}
        outerRadius={outerRadius + 6}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        style={{ filter: 'brightness(1.2) drop-shadow(0 0 8px rgba(0,0,0,0.5))' }}
      />
    </g>
  );
};

export const EvidenceChart: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [showGuide, setShowGuide] = useState(false);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const activeData = EVIDENCE_DATA[activeIndex];

  const forensicTips: Record<string, { title: string, label: string, steps: string[], icon: string }> = {
    'The Content': {
      title: 'Payload Integrity',
      label: 'Digital Forensic Content',
      icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z',
      steps: [
        'Secure original file (no filters)',
        'Run SHA-256 Hashing via StopNCII',
        'Upload hash to global blocklist'
      ]
    },
    'Perpetrator ID': {
      title: 'Identity Trace',
      label: 'Threat Vector ID',
      icon: 'M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1',
      steps: [
        'Capture Profile UID (Numeric ID)',
        'Log full URL of source profile',
        'Map ISP connection via subpoena'
      ]
    },
    'Timestamp': {
      title: 'Temporal Proof',
      label: 'Clock Synchronization',
      icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
      steps: [
        'Log Server-side UTC timestamp',
        'NTP-synchronized event logs',
        'Verify metadata EXIF/Header'
      ]
    }
  };

  const currentTip = forensicTips[activeData.name] || forensicTips['The Content'];

  return (
    <div className="w-full flex flex-col gap-6">
      <div className="w-full bg-[#262626] border border-neutral-700 rounded-xl p-6 md:p-8 raised-card !bg-opacity-40 transition-all duration-500">
        <div className="flex flex-col xl:flex-row items-center gap-10">
          
          {/* Interactive Chart Area */}
          <div className="w-full xl:w-1/2 h-[320px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <defs>
                  <filter id="forensicGlow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>
                <Pie
                  activeIndex={activeIndex}
                  activeShape={renderActiveShape}
                  data={EVIDENCE_DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={95}
                  dataKey="value"
                  onMouseEnter={onPieEnter}
                  stroke="none"
                  paddingAngle={6}
                  animationDuration={600}
                  animationBegin={0}
                >
                  {EVIDENCE_DATA.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color} 
                      style={{ 
                        outline: 'none',
                        cursor: 'pointer',
                        transition: 'opacity 0.3s ease'
                      }}
                      opacity={activeIndex === index ? 1 : 0.6}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 mb-1">Audit Unit</span>
              <span className="text-2xl font-black text-white uppercase tracking-tighter" style={{ color: activeData.color }}>0{activeIndex + 1}</span>
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{activeData.name}</span>
            </div>
          </div>

          {/* Forensic Readout Panel */}
          <div className="w-full xl:w-1/2 flex flex-col">
            <div className="mb-6 flex items-start gap-4">
               <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 shadow-inner" style={{ color: activeData.color }}>
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={currentTip.icon} />
                 </svg>
               </div>
               <div>
                 <h4 className="text-white font-black text-xl uppercase tracking-tight">{currentTip.title}</h4>
                 <p className="text-[10px] font-black uppercase tracking-[0.2em] transition-colors duration-500" style={{ color: activeData.color }}>
                   {currentTip.label}
                 </p>
               </div>
            </div>

            <div className="space-y-4 mb-8">
              {currentTip.steps.map((step, i) => (
                <div key={i} className="flex items-center gap-4 group">
                  <div className="w-6 h-6 rounded bg-neutral-900 border border-neutral-700 flex items-center justify-center text-[10px] font-black transition-all duration-300" 
                       style={{ color: activeData.color, borderColor: `${activeData.color}40` }}>
                    {i + 1}
                  </div>
                  <span className="text-sm text-gray-300 font-medium group-hover:text-white transition-colors">{step}</span>
                </div>
              ))}
            </div>

            <div className="mt-auto p-4 bg-black/40 rounded-xl border border-neutral-800 flex items-center justify-between shadow-inner">
                <div className="flex flex-col">
                  <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Weighting</p>
                  <p className="text-lg font-black text-white">{activeData.value}%</p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">SAPS Priority</p>
                  <p className="text-xs font-bold text-cyan-400 uppercase tracking-wide">Critical</p>
                </div>
            </div>
          </div>
        </div>

        {/* Legend / Tabs */}
        <div className="grid grid-cols-3 gap-3 mt-10 border-t border-neutral-700/50 pt-8 no-print">
          {EVIDENCE_DATA.map((entry, index) => (
            <button 
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`flex flex-col items-center p-4 rounded-xl transition-all duration-300 border ${
                activeIndex === index 
                ? 'bg-neutral-800 border-neutral-600 shadow-xl -translate-y-1' 
                : 'border-transparent opacity-30 hover:opacity-100 hover:bg-neutral-800/30'
              }`}
            >
              <div className="w-3 h-3 rounded-full mb-3 shadow-md" style={{ backgroundColor: entry.color }}></div>
              <span className="text-[10px] font-black uppercase tracking-widest text-white">{entry.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Enhanced Collection Guide Toggle */}
      <div className="raised-card rounded-xl overflow-hidden transition-all duration-500 bg-neutral-900/30 border border-neutral-700">
        <button 
          onClick={() => setShowGuide(!showGuide)}
          className="w-full flex items-center justify-between p-6 hover:bg-neutral-800/40 transition-colors group"
        >
          <div className="flex items-center gap-4">
            <div className={`p-2.5 rounded-lg bg-neutral-800 border transition-all duration-300 ${showGuide ? 'border-cyan-500 shadow-[0_0_10px_rgba(0,170,204,0.3)]' : 'border-neutral-700'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${showGuide ? 'text-cyan-400' : 'text-gray-500 group-hover:text-cyan-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div className="text-left">
              <h5 className="text-white font-black text-lg uppercase tracking-tight">Evidence Collection Guide</h5>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-0.5">Tactical Data Preservation Protocol</p>
            </div>
          </div>
          <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-gray-600 transition-transform duration-500 ${showGuide ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        <div className={`transition-all duration-500 ease-in-out ${showGuide ? 'max-h-[3000px] border-t border-neutral-800 opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}>
          <div className="p-8 space-y-12">
            
            {/* Disclaimer / Warning */}
            <div className="bg-yellow-900/10 border border-yellow-500/20 p-4 rounded-lg flex items-start gap-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <p className="text-[11px] text-yellow-200/80 font-medium leading-relaxed uppercase tracking-wide">
                <strong>Critical:</strong> Do not engage the perpetrator while collecting evidence. Use a separate, safe device if you suspect your primary phone has spyware or remote monitoring active.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
              {/* Steps preserved as in previous version... */}
              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 003 15.364" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 01</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">Zero Alteration Policy</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    <strong>Do not rename</strong> files, crop images, or use filters. Forensic software relies on the original file bitstream and hidden EXIF headers to verify that the evidence has not been tampered with.
                  </p>
                </div>
              </div>

              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 02</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">Full URL & Header Capture</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    Screenshots are secondary. You must document the <strong>full browser URL</strong> (including the query parameters). For emails, export the "Original Message" to include the full routing headers for server-side verification.
                  </p>
                </div>
              </div>

              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 03</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">Metadata & UID Archiving</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    Abusers often change handles. Capture the <strong>numeric User ID (UID)</strong> found in profile settings or source code. This persistent ID remains the same even if the perpetrator changes their name or bio.
                  </p>
                </div>
              </div>

              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 04</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">StopNCII Hashing</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    Visit <strong>StopNCII.org</strong>. Their tool generates a SHA-256 hash (digital fingerprint) of your files directly in your browser. This hash is shared with platforms to block current and future uploads without you ever sharing the image.
                  </p>
                </div>
              </div>

              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 05</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">Physical Backup (Offline)</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    Once collected, move all evidence to an <strong>encrypted USB drive</strong> and remove it from the device. This creates an offline "Master Copy" that cannot be remotely deleted or wiped by an abuser with device access.
                  </p>
                </div>
              </div>

              <div className="flex gap-5 group">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400 transition-colors group-hover:border-cyan-500/50 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-500 font-black text-[10px] uppercase tracking-widest px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">Step 06</span>
                    <h6 className="text-white font-black uppercase text-sm tracking-tight">Timeline Log</h6>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-medium">
                    Maintain a simple spreadsheet or document of every interaction, threat, or leak. Include the date, time, platform, and a reference to the relevant evidence file on your USB. This becomes your <strong>Exhibit List</strong> in court.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-center pt-8 border-t border-neutral-800/50">
              <button 
                onClick={() => setShowGuide(false)}
                className="group flex items-center gap-3 text-[11px] font-black uppercase tracking-[0.2em] text-gray-500 hover:text-white transition-all"
              >
                <div className="w-6 h-6 rounded bg-neutral-800 border border-neutral-700 flex items-center justify-center group-hover:border-cyan-500 group-hover:text-cyan-400">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 15l7-7 7 7" />
                   </svg>
                </div>
                <span>Close Collection Protocol</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};