
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // IMPORTANT: Set base to './' for relative paths in GH Pages
  // OR set it to '/<repository-name>/' if you are deploying to a project page
  base: './', 
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    // Generate a single CSS file and JS chunks for easier embedding
    rollupOptions: {
      output: {
        entryFileNames: 'assets/[name].js',
        chunkFileNames: 'assets/[name].js',
        assetFileNames: 'assets/[name].[ext]'
      }
    }
  }
});
