import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { PageHero } from './components/PageHero';
import { ContactForm } from './components/ContactForm';
import { Testimonials } from './components/Testimonials';
import { IntelHub } from './components/IntelHub'; 
import { SearchMafiaHub } from './components/SearchMafiaHub';
import { Solutions } from './components/Solutions';
import { Academy } from './components/Academy';
import { SEO } from './components/SEO';
import { CMS } from './constants';
import { useScrollTitle } from './hooks/useScrollTitle';

// Legal Page Component
const Legal: React.FC<{ type: string }> = ({ type }) => {
    const title = type === 'terms' ? 'Terms & Disclaimer' : 'Privacy Policy';
    return (
        <div className="animate-fade-in pb-12 max-w-4xl mx-auto">
            <SEO title={title} description={`WMC ${title}`} />
            <div className="raised-card p-8 md:p-12 bg-[#1C1C1C] border border-neutral-800 rounded-xl">
                <h1 className="text-3xl font-black text-white uppercase mb-8 border-b border-white/10 pb-4">{title}</h1>
                <div className="space-y-6 text-gray-400 text-sm leading-relaxed font-medium">
                    <p>
                        <strong>1. Purpose:</strong> This platform is a tactical playbook and educational resource. 
                        WMC (WeMustCreate) provides digital infrastructure and strategic advice. We are not a law firm.
                    </p>
                    <p>
                        <strong>2. Responsibility:</strong> By using this platform, you agree that your digital sovereignty is your own responsibility.
                        We provide the tools and intelligence; you provide the intent and execution.
                    </p>
                    <p>
                        <strong>3. Data:</strong> We adhere to strict POPIA (Protection of Personal Information Act) guidelines. 
                        Information submitted via our secure endpoints is encrypted and never sold to third parties.
                    </p>
                    {type === 'terms' && (
                        <p>
                            <strong>4. Services:</strong> All service engagements are subject to a separate Service Level Agreement (SLA) 
                            which will be provided upon project initiation.
                        </p>
                    )}
                </div>
            </div>
        </div>
    );
};

// Home Page Component
const Home: React.FC<{ onNavigate: (p: string) => void }> = ({ onNavigate }) => {
    const content = CMS.pages.home;
    return (
        <div className="animate-fade-in">
            <SEO title={content.title} description={content.description} />
            <PageHero 
                title={content.title}
                tagline={content.tagline} 
                image={content.heroImage}
                cta={content.cta}
                onCtaClick={() => onNavigate('solutions')}
            />
            
            {/* Featured Solutions */}
            <div className="max-w-7xl mx-auto px-4 mb-20">
                <div className="text-center mb-10"><span className="text-[#00AACC] font-black uppercase tracking-[0.2em] text-xs">Services</span><h2 className="text-3xl font-black text-white uppercase">Featured Solutions</h2></div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {['Audit Services', 'Reputation Repair', 'Web Packages', 'Ads Management'].map((s,i) => (
                        <div key={i} onClick={() => onNavigate('solutions')} className="raised-card p-6 bg-[#1C1C1C] hover:border-[#00AACC] cursor-pointer group transition-colors">
                            <h4 className="text-white font-bold group-hover:text-[#00AACC] text-sm uppercase">{s}</h4>
                        </div>
                    ))}
                </div>
            </div>

            {/* Intel Snapshot */}
            <div className="mb-20">
                 <div className="text-center mb-8"><span className="text-[#D4AF37] font-black uppercase tracking-[0.2em] text-xs">Resources</span><h2 className="text-3xl font-black text-white uppercase">Intel Snapshot</h2></div>
                 <div className="bg-neutral-900/50 p-8 rounded-xl border border-white/5 text-center">
                    <p className="text-gray-400 mb-6">Access tactical tools and resources.</p>
                    <button onClick={() => onNavigate('intel')} className="text-[#D4AF37] font-black uppercase text-xs tracking-widest border border-[#D4AF37]/30 px-6 py-3 rounded hover:bg-[#D4AF37] hover:text-black transition-all">Open Intel Hub</button>
                 </div>
            </div>

            <Testimonials />
        </div>
    );
};

// Mafia Page Wrapper (reuses existing hub with SEO)
const MafiaPage: React.FC<{ onNavigate: (p: string) => void }> = ({ onNavigate }) => {
    const content = CMS.pages.mafia;
    return (
        <>
            <SEO title={content.title} description={content.description} />
            <SearchMafiaHub onNavigate={onNavigate} />
        </>
    );
};

// Connect Page
const Connect: React.FC = () => {
    const content = CMS.pages.connect;
    return (
        <div className="animate-fade-in pb-12">
            <SEO title={content.title} description={content.description} />
            <PageHero 
                title={content.title}
                tagline={content.tagline} 
                image={content.heroImage}
            />
            <ContactForm defaultService="" />
            
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                 <div className="raised-card p-6"><h4 className="text-white font-bold uppercase mb-2">Location</h4><p className="text-gray-400 text-sm">Johannesburg, South Africa</p></div>
                 <div className="raised-card p-6"><h4 className="text-white font-bold uppercase mb-2">Social</h4><p className="text-gray-400 text-sm">LinkedIn | Facebook</p></div>
                 <div className="raised-card p-6"><h4 className="text-white font-bold uppercase mb-2">Support</h4><p className="text-gray-400 text-sm">searchplaybook@proton.me</p></div>
            </div>
        </div>
    );
};

// Intel Page Wrapper
const IntelPage: React.FC<{ onNavigate: (p: string) => void }> = ({ onNavigate }) => {
    const content = CMS.pages.intel;
    return (
        <>
            <SEO title={content.title} description={content.description} />
            <IntelHub onNavigate={onNavigate} />
        </>
    );
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  useScrollTitle();

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash) setActiveTab(hash);
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (page: string) => {
    setActiveTab(page);
    window.location.hash = page; 
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderContent = () => {
    // Basic route matching for legal pages
    if (activeTab.startsWith('legal/')) {
        const type = activeTab.split('/')[1];
        return <Legal type={type} />;
    }

    switch (activeTab) {
        case 'home': return <Home onNavigate={handleNavigate} />;
        case 'solutions': return <Solutions />;
        case 'intel': return <IntelPage onNavigate={handleNavigate} />;
        case 'academy': return <Academy />;
        case 'mafia': return <MafiaPage onNavigate={handleNavigate} />;
        case 'connect': return <Connect />;
        default: return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#111] text-gray-200 font-sans selection:bg-[#00AACC] selection:text-black flex flex-col">
      <Header activeTab={activeTab} onNavigate={handleNavigate} />
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {renderContent()}
      </main>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
};

export default App;