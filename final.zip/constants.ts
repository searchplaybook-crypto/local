
import { TimelineData, EvidenceData, SimpleStatData } from './types';

export const COLORS = {
  gold: '#D4AF37',
  goldDark: '#B8860B',
  cyan: '#00AACC',
  navy: '#60A5FA',
  navyDark: '#3B82F6',
  red: '#EF4444',
  green: '#10B981',
  copperRed: '#B87333',
  background: '#1c1c1c',
  surface: '#2a2a2a',
  text: '#E0E0E0',
  textHighlight: '#FAFAFA',
};

// --- CMS DATA STORE ---
export const CMS = {
  identity: {
    short: 'WMC',
    full: 'WeMustCreate',
    tagline: 'Search Playbook',
    location: 'South Africa',
    contact: 'searchplaybook@proton.me'
  },
  heroSlides: [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1920',
      title: 'Digital',
      titleHighlight: 'Sovereignty',
      desc: 'Take back control of your digital footprint. Security, Privacy, and Visibility protocols for the modern web.',
      badge: 'Protocol Alpha',
      gradient: 'from-cyan-400 to-blue-600',
      cta: 'Start Audit',
      target: 'solutions'
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1920',
      title: 'Market',
      titleHighlight: 'Dominance',
      desc: 'Own your traffic. Own your data. Build a permanent digital asset that grows with your business.',
      badge: 'Growth Engine',
      gradient: 'from-yellow-400 to-orange-600',
      cta: 'View Solutions',
      target: 'solutions'
    }
  ],
  nav: [
    { title: 'Home', id: 'home', visible: true },
    { title: 'Solutions', id: 'solutions', visible: true },
    { title: 'Intel', id: 'intel', visible: true },
    { title: 'Academy', id: 'academy', visible: true },
    { title: 'Mafia', id: 'mafia', visible: true },
    { title: 'Connect', id: 'connect', visible: true }
  ],
  pages: {
    home: {
      title: "Home",
      tagline: "Visibility & Privacy: Master the digital game",
      heroImage: "hero-home.jpg",
      cta: "Explore Solutions",
      description: "Visibility & Privacy: Master the digital game. Explore our audit services and digital solutions."
    },
    solutions: {
      title: "Solutions",
      tagline: "Privacy | Safety | Visibility",
      heroImage: "hero-solutions.jpg",
      description: "Privacy, Safety, and Visibility protocols. Audit services, Reputation Management, and Web Packages."
    },
    intel: {
      title: "Intel",
      tagline: "Tactical resources for digital safety and visibility",
      heroImage: "hero-intel.jpg",
      description: "Tactical resources for digital safety. OSINT tools, footprint analysis, and tactical checklists."
    },
    academy: {
      title: "Academy",
      tagline: "Learn, Adapt, Empower",
      heroImage: "hero-academy.jpg",
      description: "Learn SEO, Ads, and Privacy. Adapt to the digital landscape. Empower your future."
    },
    mafia: {
      title: "Mafia",
      tagline: "Referral Power, Community Strength",
      heroImage: "hero-mafia.jpg",
      description: "Join the Search Mafia. Referral power and community strength for digital growth."
    },
    connect: {
      title: "Connect",
      tagline: "Start your digital optimization journey today",
      heroImage: "hero-connect.jpg",
      description: "Contact WMC. Start your digital optimization journey today."
    }
  },
  services: {
    audit: [
      { id: 'free-audit', title: 'Free Audit', price: 'R750', frequency: 'once-off' },
      { id: 'full-audit', title: 'Full Digital Footprint Audit', price: 'R1500', frequency: 'once-off' }
    ],
    catalogue: [
      { title: 'Reputation Management', price: 'R335', frequency: 'PM', description: 'Monitor & repair digital presence.' },
      { title: 'Business Social Marketing Tool', price: 'R330', frequency: 'PM', description: 'Unified social scheduling & analytics.' },
      { title: 'Web Basic', price: 'R130', frequency: 'PM', description: 'Secure hosting & basic maintenance.' },
      { title: 'Web Pro', price: 'R194', frequency: 'PM', description: 'Performance hosting for growth.' },
      { title: 'Web Exec', price: 'R156', frequency: 'PM', description: 'Priority support hosting package.' },
      { title: 'Online Banners', price: 'R440', frequency: 'PM', description: 'Custom ad creatives & display assets.' },
      { title: 'Google Ads', price: 'R1730', frequency: 'PM', description: 'Expert PPC campaign management.' },
      { title: 'Facebook Ads', price: 'R1150', frequency: 'PM', description: 'Targeted social media campaigns.' },
      { title: 'Conversation AI', price: 'R985', frequency: 'PM', description: 'Automated lead response bot.' },
      { title: 'Campaign Pro', price: 'R400', frequency: 'PM', description: 'Advanced marketing tools suite.' }
    ],
    setAndForget: [
      { id: 'basic', title: 'Web Basic', price: 'R130', frequency: 'PM', tier: 'Starter', highlight: true, description: 'Essential digital presence.' },
      { id: 'pro', title: 'Web Pro', price: 'R194', frequency: 'PM', tier: 'Pro', highlight: false, description: 'Professional visibility.' },
      { id: 'exec', title: 'Web Exec', price: 'R156', frequency: 'PM', tier: 'Exec', highlight: false, description: 'Executive branding.' },
      { id: 'campaign', title: 'Campaign Pro', price: 'R400', frequency: 'PM', tier: 'Campaign Pro', highlight: false, description: 'Aggressive promotion.' }
    ]
  },
  // Legacy data kept for charts compatibility
  solutions: [
    { id: 'privacy-protocol', title: 'Privacy Protocol', desc: 'GDPR & POPIA Compliance', icon: 'shield' },
    { id: 'safety-protocol', title: 'Safety Protocol', desc: 'Threat Mitigation', icon: 'lock' },
    { id: 'visibility-protocol', title: 'Visibility Protocol', desc: 'SEO & Ranking', icon: 'eye' }
  ],
  caseStudies: [
    {
      client: "Family Kitchen",
      industry: "Hospitality",
      challenge: "Reliant on Facebook algorithms, zero organic traffic.",
      solution: "Deployed Visibility Protocol & Owned Website Asset.",
      metrics: ["1,172% Traffic Growth", "Zero Ad Spend", "Top 3 Ranking"],
      downloadUrl: "#"
    },
    {
      client: "Tsumkwe Net",
      industry: "ISP / Tech",
      challenge: "Invisible to corporate clients in remote areas.",
      solution: "Reliability Protocol & Digital Trust Signals.",
      metrics: ["R45k Contract Won", "3 Weeks Post-Launch", "Regional Dominance"],
      downloadUrl: "#"
    }
  ],
  syndicate: {
    intro: "A network of digital architects and scouts. We provide the infrastructure, the training, and the tactical tools. You connect the disconnected and build the empire.",
    steps: [
      { id: '01', title: 'Scout', desc: 'Identify businesses in your area.' },
      { id: '02', title: 'Audit', desc: 'Use our Free Audit Tool.' },
      { id: '03', title: 'Connect', desc: 'Submit the lead via our secure channel.' },
      { id: '04', title: 'Profit', desc: 'You earn commission.' }
    ]
  }
};

export const TIMELINE_DATA: TimelineData[] = [
  { stage: 'Interim Interdict', days: 3, color: COLORS.cyan, description: 'Civil: Immediate Legal Protection' },
  { stage: 'Final Order', days: 60, color: COLORS.copperRed, description: 'Civil: Permanent Removal Order' },
  { stage: 'SAPS: Forensics', days: 180, color: COLORS.gold, description: 'Criminal: Evidence Analysis Backlog' },
  { stage: 'NPA: Decision', days: 365, color: '#A16207', description: 'Criminal: Decision to Prosecute' },
  { stage: 'Court: Trial', days: 730, color: '#666666', description: 'Criminal: Trial & Postponements' },
  { stage: 'Final Verdict', days: 1095, color: COLORS.red, description: 'Criminal: Conviction (Avg 3 Years)' },
];

export const EVIDENCE_DATA: EvidenceData[] = [
  { name: 'The Content', value: 33, color: COLORS.cyan },
  { name: 'Perpetrator ID', value: 33, color: COLORS.navyDark },
  { name: 'Timestamp', value: 34, color: COLORS.goldDark },
];

export const GBV_SENTENCE_DATA: SimpleStatData[] = [
  { name: 'Not Long Enough', value: 72.7, color: COLORS.red },
  { name: 'Adequate', value: 27.3, color: COLORS.navy },
];

export const COURT_SATISFACTION_DATA: SimpleStatData[] = [
  { name: 'Dissatisfied', value: 55.2, color: COLORS.gold },
  { name: 'Satisfied', value: 44.8, color: COLORS.cyan },
];

export const GLOBAL_PREVALENCE_DATA: SimpleStatData[] = [
  { name: 'Witnessed Violence', value: 85, color: COLORS.red },
  { name: 'Personal Experience', value: 38, color: COLORS.gold },
];
